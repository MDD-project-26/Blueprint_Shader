# Battery stack (slider-driven, sits in page flow) — integration guide

This file sits inside `dist-battery/`, the folder it describes: a path
written as `dist-battery/assets/` below means `assets/` right here. It is
Part C of the project's full guide; any other "Part" it mentions is a
different canvas that isn't in this folder.

`battery-preview.html` is the working reference — run `pnpm build:battery`
and serve `dist-battery/battery-preview.html` (or `pnpm preview:battery`) to
see the expected behavior. The two dark placeholder sections above and below
the battery are only there to make the page scroll, the way your own page
will. Read that file's own top HTML comment too; this section covers the same
contract.

In the repo, `battery-preview.html` also demos the Part D canvas below this
one, in an iframe. The `dist-battery/` build strips that out, so the folder
you receive contains the vertical stack only.

## 1. Copy the DOM structure

```html
<div id="battery-stage">
  <canvas id="canvas" data-battery="true" data-preview="true"></canvas>
  <div id="perf-monitor"><div id="perf-monitor-text"></div><canvas id="perf-history" width="140" height="32"></canvas></div>
  <canvas id="axis-gizmo" width="84" height="84"></canvas>
  <div id="react-controls-root"></div>
</div>
<script type="module" src="/assets/battery-preview-XXXXXXXX.js"></script>
<link rel="stylesheet" href="/assets/battery-preview-XXXXXXXX.css">
```

Copy this block, and the CSS in `battery-preview.html`'s `<head>` for
`#battery-stage`, `canvas#canvas`, `#perf-monitor` and `#axis-gizmo`:

- `#battery-stage` is the module's own box. Everything it draws stays inside
  it. Size it however your layout needs — the reference uses a full viewport
  (`height: 100svh`) — and put it in normal document flow between your own
  sections. It must keep `position: relative` (the count slider is positioned
  against it) and `overflow: hidden`.
- Both `data-battery="true"` and `data-preview="true"` on the canvas are
  required. Together they select this embed's behavior; with either one
  missing you get a different route of the internal tool.
- `canvas#canvas` keeps `touch-action: pan-y`, so a finger on the canvas
  scrolls the page.
- `#perf-monitor`/`#axis-gizmo` must stay in the DOM (hidden via CSS) even
  though you'll never see them — the script looks them up unconditionally and
  isn't null-safe around them. Same constraint as Part B.
- `#react-controls-root` is where the count slider mounts.

Leave behind the two `.demo-placeholder` sections and `.render-statuses` (the
"Rendering / Paused" pill in the corner): they are demo aids, and the script
doesn't need either.

## 2. Load the script and stylesheet

Like Part B, this bundle is **not** tree-shaken — it ships the full
React/Tailwind bundle because the slider is pre-built. Load both
`dist-battery/assets/battery-preview-*.js` and `battery-preview-*.css`
(content-hashed — use the actual filenames, or keep the `<script>`/`<link>`
tags Vite generated in `dist-battery/battery-preview.html`).

It isn't freely relocatable either: the stylesheet loads its webfonts through
root-absolute URLs baked in at build time. Copy `dist-battery/assets/` and
`dist-battery/fonts/` as-is and serve them at `/assets/` and `/fonts/` from
your site root. If your hosting can't serve from root, tell us and we'll
adjust the build's asset base path before you integrate.

## 3. Host the 3D model

Copy `dist-battery/models/NGEN_assets.obj` and `NGEN_assets.mtl` so they're
served at `/models/NGEN_assets.obj` and `/models/NGEN_assets.mtl` **relative
to your site root** — that exact path is hardcoded in the script. They are the
only two files in `dist-battery/models/`. `favicon.png` is only used by the
reference page.

## 4. That's it — no API to wire up

Everything below is built in:

- **Start.** Once the model has loaded, the stack shows three modules held
  slightly apart (50px on screen). When all but the last 200px of the canvas
  has scrolled into view, they ease together into the assembled stack (800ms).
  This plays once per page load.
- **Slider.** A horizontal slider at the bottom center of the stage sets the
  number of modules, 3 to 9; the numbers under it are click targets too.
  Added modules slide and fade in beneath the top unit, removed ones slide
  and fade out, and the camera re-centers on the stack as it grows or shrinks.
- **Pointer.** Dragging with a mouse rotates the model. The mouse wheel and
  touch are left alone, so both scroll your page as usual.
- **Background.** The canvas paints its own opaque white background.
- **Reduced motion.** With `prefers-reduced-motion: reduce`, the stack appears
  assembled and count changes apply instantly.

It also keeps out of the host page's way:

- **Off screen, it stops.** Rendering halts once the stage is more than about
  200px outside the viewport and resumes as it comes back, so it costs nothing
  while the user is elsewhere on the page.
- **No keyboard shortcuts, no file-drop handling.** Space, arrows and typing
  behave as they do on the rest of your page.
- **It follows its own box.** If your layout resizes `#battery-stage`, the
  canvas re-fits; a window resize isn't required.

## 5. Things to know before you integrate

- **The stylesheet is global.** It includes Tailwind's base reset plus this
  project's own base rules, which set `body` background and text color, the
  `html` font, and a default border color on every element. Loaded on your
  page as-is, it will restyle parts of the page outside the battery. If that
  conflicts with your own styles, tell us and we'll scope the stylesheet to
  `#battery-stage` before you integrate.
- **One instance per page.** The script finds its elements by id (`canvas`,
  `react-controls-root`, …), so it can't be embedded twice on one page, and
  none of those ids can be reused elsewhere on it. It also can't share a page
  with Part A, B or D, which use the same ids — except by putting the other
  one in an iframe (see Part D).
- **No teardown.** The script starts when it loads and has no `destroy()`. On
  a regular page load that's fine. If your site is a single-page app that
  mounts and removes this section without a full reload, its listeners and
  WebGL context would outlive the section — tell us and we'll add a teardown
  call.
- **No count API.** The built-in slider is the only way to change the number
  of modules. If you need to drive it from your own UI, or read the current
  count, tell us and we'll expose it, the way Part A exposes
  `window.heroScene`.
