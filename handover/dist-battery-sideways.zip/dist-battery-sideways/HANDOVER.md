# EP5/EP12 sideways batteries (model buttons + slider) — integration guide

This file sits inside `dist-battery-sideways/`, the folder it describes: a path
written as `dist-battery-sideways/assets/` below means `assets/` right here. It is
Part D of the project's full guide; any other "Part" it mentions is a
different canvas that isn't in this folder.

`battery-sideways.html` is the working reference — run
`pnpm build:battery-sideways` and serve
`dist-battery-sideways/battery-sideways.html` (or
`pnpm preview:battery-sideways`). It is a separate bundle from Part C with its
own output folder; nothing in `dist-battery/` is needed here, and nothing here
is needed for Part C.

## 1. Copy the DOM structure

```html
<section id="battery-stage" aria-label="Sideways battery stacking">
  <canvas id="canvas" data-battery="true" data-preview="true" data-stacking="sideways"></canvas>
  <h1 class="module-title">EP5 / EP12 · Sideways stacking</h1>
  <div id="perf-monitor"><div id="perf-monitor-text"></div><canvas id="perf-history" width="140" height="32"></canvas></div>
  <canvas id="axis-gizmo" width="84" height="84"></canvas>
  <div id="react-controls-root"></div>
</section>
<script type="module" src="/assets/battery-sideways-XXXXXXXX.js"></script>
<link rel="stylesheet" href="/assets/battery-sideways-XXXXXXXX.css">
```

Copy this block, and the CSS in `battery-sideways.html`'s `<head>`:

- `#battery-stage` is the module's own box. Everything it draws stays inside
  it. Size it however your layout needs — the reference uses a full viewport
  (`height: 100svh`) — and put it in normal document flow between your own
  sections. It must keep `position: relative` (the controls are positioned
  against it) and `overflow: hidden`.
- All three canvas attributes are required: `data-battery="true"`,
  `data-preview="true"` and `data-stacking="sideways"`. Without the third you
  get the vertical stack instead; with either of the first two missing you
  get a different route of the internal tool.
- `canvas#canvas` keeps `touch-action: pan-y`, so a finger on the canvas
  scrolls the page.
- `#perf-monitor`/`#axis-gizmo` must stay in the DOM (hidden via CSS) even
  though you'll never see them — the script looks them up unconditionally and
  isn't null-safe around them.
- `#react-controls-root` is where the model buttons and count slider mount.
- `.module-title` is plain HTML over the canvas and is yours to restyle,
  reword or delete; the script doesn't look for it.

## 2. Load the script and stylesheet

This bundle is **not** tree-shaken — it ships the full React/Tailwind bundle
because the controls are pre-built. Load both
`dist-battery-sideways/assets/battery-sideways-*.js` and
`battery-sideways-*.css` (content-hashed — use the actual filenames, or keep
the `<script>`/`<link>` tags Vite generated in
`dist-battery-sideways/battery-sideways.html`).

It isn't freely relocatable either: the stylesheet loads its webfonts through
root-absolute URLs baked in at build time. Copy `dist-battery-sideways/assets/`
and `dist-battery-sideways/fonts/` as-is and serve them at `/assets/` and
`/fonts/` from your site root. If your hosting can't serve from root, tell us
and we'll adjust the build's asset base path before you integrate.

## 3. Host the 3D models

Copy the four files in `dist-battery-sideways/models/` so they're served at
`/models/EP5-battery-stack.obj`, `/models/EP5-battery-stack.mtl`,
`/models/EP12-battery-stack.obj` and `/models/EP12-battery-stack.mtl`
**relative to your site root** — those exact paths are hardcoded in the
script. Both models are fetched on load and placed in the same scene.
`favicon.png` is only used by the reference page.

## 4. That's it — no API to wire up

Everything below is built in:

- **Scene.** The EP5 and EP12 stand side by side, far enough apart that only
  one is in view at a time. It opens on the EP5.
- **Start.** Once the models have loaded, each shows three modules held
  slightly apart (50px on screen). When all but the last 200px of the canvas
  has scrolled into view, they ease together (800ms). This plays once per
  page load.
- **Model buttons.** The EP5 / EP12 buttons at the bottom center move the
  camera to that model (about half a second). Nothing is reloaded. The model
  the camera arrives at restacks: its modules sit held apart for 300ms, then
  ease together (800ms).
- **Slider.** Sets the number of modules, 1 to 4, for both models at once; the
  numbers under it are click targets too. Added modules slide and fade in,
  removed ones slide and fade out, and the camera re-centers on the row.
- **Pointer.** Dragging with a mouse rotates the model. The mouse wheel and
  touch are left alone, so both scroll your page as usual.
- **Reduced motion.** With `prefers-reduced-motion: reduce`, the modules
  appear assembled, and count changes and model switches skip their
  animations.

It also keeps out of the host page's way:

- **Off screen, it stops.** Rendering halts once the stage is more than about
  200px outside the viewport and resumes as it comes back, so it costs nothing
  while the user is elsewhere on the page.
- **No keyboard shortcuts, no file-drop handling.** Space, arrows and typing
  behave as they do on the rest of your page.
- **It follows its own box.** If your layout resizes `#battery-stage`, the
  canvas re-fits; a window resize isn't required.

## 5. Things to know before you integrate

- **The stylesheet is global.** It includes Tailwind's base reset plus this
  project's own base rules, which set `body` background and text color, the
  `html` font, and a default border color on every element. Loaded on your
  page as-is, it will restyle parts of the page outside the module. If that
  conflicts with your own styles, tell us and we'll scope the stylesheet to
  `#battery-stage` before you integrate — or embed the module as an iframe
  (below), which isolates it completely.
- **One instance per page.** The script finds its elements by id (`canvas`,
  `react-controls-root`, …), so it can't be embedded twice in one document,
  and none of those ids can be reused elsewhere in it.
- **Together with the vertical battery stack (Part C).** Both scripts look up
  the same element ids, so they can't be loaded into one document. To show
  both on a page, put one of them in an `<iframe>` — the repo's
  `battery-preview.html` does exactly this with `battery-sideways.html`.
- **No teardown.** The script starts when it loads and has no `destroy()`. On
  a regular page load that's fine. In a single-page app that mounts and
  removes this section without a full reload, its listeners and WebGL context
  would outlive the section. Embedding it as an iframe avoids this: removing
  the iframe releases everything. Otherwise tell us and we'll add a teardown
  call.
- **No count or model API.** The built-in controls are the only way to change
  the module count or the model in view. If you need to drive them from your
  own UI, tell us and we'll expose it.
- **Render status pill (optional).** If you embed the module as an iframe on
  the same origin as your page, give the iframe `data-render-status="some-id"`
  and the script will write "Rendering" / "Paused (off screen)" into the
  element with that id on your page. Leave the attribute off and nothing
  happens.
