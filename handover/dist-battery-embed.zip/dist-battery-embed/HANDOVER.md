# Battery embed module (your controls, `createBatteryScene`) — integration guide

This file sits inside `dist-battery-embed/`, the folder it describes: a path
written as `dist-battery-embed/assets/` below means `assets/` right here. It is
Part E of the project's full guide; any other "Part" it mentions is a
different canvas that isn't in this folder.

One ES module, `dist-battery-embed/assets/battery-embed.js` (66 kB, 24 kB
gzipped), covering both the vertical stack (Part C's scene) and the sideways
EP5/EP12 pair (Part D's). It contains no React, Tailwind, stylesheet, controls
or element ids, and touches nothing on the page outside the element you give
it.

`example.html` in the same folder is a working reference with plain
host-built controls and a Destroy/Create button per scene. Serve the folder
with any static server and open it (it won't run from `file://`, since it
loads an ES module). In the repo, `pnpm dev:battery-embed` serves the same
page.

## 1. What's in the folder

- `assets/battery-embed.js` — the module. Serve it wherever you like; you
  told us `/assets/battery-embed.js`.
- `assets/battery-embed.d.ts` — its types, if you want them next to your own
  `scene.ts`.
- `models/battery/` — the six model files, named exactly as the module
  requests them: `NGEN_assets.obj`/`.mtl` (vertical), and
  `EP5-battery-stack.obj`/`.mtl` plus `EP12-battery-stack.obj`/`.mtl`
  (sideways; all four are fetched and placed in one scene). Keep the names;
  the folder is yours to choose and goes in `modelBaseUrl`.
- `example.html` — the reference page.

## 2. Markup

```html
<div class="your-sized-box">
  <canvas data-battery-canvas></canvas>
</div>
```

The module draws into `root.querySelector('canvas[data-battery-canvas]')` and
sizes to `root`, the element you pass in. Give `root` a width and a height;
that is the only layout requirement. The module sets `display: block; width:
100%; height: 100%` inline on the canvas so it fills `root`, and a `grab`
cursor, and puts all four back as it found them on `destroy()`.

## 3. API

```ts
import { createBatteryScene } from '/assets/battery-embed.js';

const scene = createBatteryScene(root, {
  variant: 'vertical',          // or 'sideways'
  count: 3,                     // vertical 3–9, sideways 1–4
  model: 'ep5',                 // sideways only; optional, defaults to 'ep5'
  reducedMotion: false,
  modelBaseUrl: '/models/battery/',
  onReady: () => {},
  onError: (error) => {},
});

scene.setCount(5);
scene.setModel('ep12');
scene.destroy();
```

- **`count`** is how many units the scene opens with. (The page builds in
  Parts C and D always opened with three.)
- **`setCount`** adds or removes units with the slide-and-fade animation; on
  `sideways` it applies to both models at once. Called while the models are
  still loading, the latest value is kept and used when they arrive.
- **`setModel`** moves the camera to that model on `sideways`; it does nothing
  on `vertical`. It can also be called while loading.
- **`destroy`** removes every listener and observer, stops the render loop,
  cancels a model download still in flight and frees the scene's GPU buffers
  and shaders. No callback fires after it. Calling it twice is harmless, as is
  calling `setCount`/`setModel` afterwards.
- **`onReady`** fires once, when the models have loaded and the scene is
  drawing. Until then the canvas shows its plain white background.
- **`onError`** receives the error if WebGL is unavailable, or a model file is
  missing or isn't the expected asset. The canvas stays blank in that case.
- **Thrown, not reported:** mistakes in the arguments throw straight away —
  an unknown `variant` or `model` and a missing canvas throw a `TypeError`, a
  `count` outside the variant's range (in the options or in `setCount`) a
  `RangeError`.
- **`reducedMotion`** is read once, at creation. To follow a change of the
  user's setting, destroy the scene and create it again.

## 4. Behavior

Unchanged from Parts C and D:

- **Start.** Once loaded, the units sit held slightly apart (50px on screen).
  When all but the last 200px of the canvas has scrolled into view, they ease
  together (800ms). Once per scene; a `setCount` before that assembles them
  immediately.
- **Count changes.** Added units slide and fade in, removed ones slide and
  fade out, and the camera re-centers on the stack.
- **EP5/EP12.** The two stand side by side, far enough apart that only one is
  in view. `setModel` moves the camera across (about half a second); the model
  it arrives at sits held apart for 300ms, then eases together (800ms).
- **Reduced motion.** The units appear assembled, and count changes and the
  restack on a model switch skip their animations.
- **Off screen, it stops.** Rendering halts once the canvas is more than about
  200px outside the viewport and resumes as it returns.
- **Pointer.** Dragging with a mouse or pen rotates the model. The wheel and
  touch are left alone, so both scroll your page. No keyboard shortcuts.
- **Background.** The canvas paints its own opaque white background.

New in this build:

- **It follows `root`.** When your layout resizes `root`, the canvas re-fits
  and the model is re-framed to the new proportions. A `root` with no size yet
  (mounted hidden) is fine; drawing starts once it has one.
- **Several scenes per page.** Every `createBatteryScene` call is independent,
  so the vertical and sideways variants can share a page.
- **Remounting.** After `destroy()`, a new scene can be created on the same
  canvas element or on a fresh one. Don't run two scenes on one canvas at the
  same time.
- **No storage, no globals.** The module doesn't read or write `localStorage`
  and adds nothing to `window`.
