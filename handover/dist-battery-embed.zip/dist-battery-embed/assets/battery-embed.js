function e(e){let t=e.objects.map((e,t)=>({...e,index:t})).filter(e=>/^Battery_Nine_Stack_-_(Slave(?:_with_Legs|_\d+)?|Master)$/.test(e.name)).sort((e,t)=>e.bounds.minY-t.bounds.minY);if(t.length!==9||e.objects.length!==9||!t[0].name.endsWith(`with_Legs`)||!t[8].name.endsWith(`Master`))return null;let n=t[2].bounds.minY-t[1].bounds.minY;if(!(n>0))return null;let r=t[8],i=t[7].bounds.maxY-r.bounds.minY,a=n*1.4,o=e=>Math.sin(Math.PI*e/2),s=e=>Math.asin(e)*2/Math.PI,c=e=>e<.5?8*e**4:1-(-2*e+2)**4/2,l=new Map,u=(e,t)=>`${e[t]},${e[t+1]},${e[t+2]}`;for(let t=0;t<e.objectIndex.length;t++)l.set(u(e.positions,t*3),e.objectIndex[t]);let d=[];for(let t=0;t<e.linePositions.length;t+=6)d.push(l.get(u(e.linePositions,t)));if(d.some(e=>e===void 0))return null;let f=(e,t)=>{let n=[];for(let r=0;r<e.length;){let i=e[r],a=r+1;for(;a<e.length&&e[a]===i;)a++;n.push({index:i,start:r*t,end:a*t}),r=a}return n},p=f(e.objectIndex,3),m=f(d,6),h=new Map,g=new Uint8Array(t.length),_,v=e.objects.slice(),y=new Float64Array(t.length).fill(NaN),b=new Float64Array(t.length).fill(NaN),x=!1,S=9,C=!0,w=!0,T,E=new Map(t.map(e=>[e.index,0])),D=new Map(t.map(e=>[e.index,0])),O=new Set(t.map(e=>e.index)),k=null,A=!1,j=e=>Math.max(0,Math.min(1,e)),M=()=>x?[t[0],...t.slice(1,S-1),r]:t,N=e=>(e-9)*n;function P(e){if(!k?.running)return;let t=Math.max(0,Math.min(k.duration,k.time+e-k.at));k.time=t,k.at=e,k.running=t<k.duration;let n=new Set;for(let e of k.tracks){if(e.after&&t<e.start)continue;let r=Math.max(0,t-e.start),i=j(r/e.duration),a=e.leaving?1-o(1-i):e.settle?c(i):o(i),s=e.lowY+(e.highY-e.lowY)*a,l=e.lowX+(e.highX-e.lowX)*a;(E.get(e.index)!==s||D.get(e.index)!==l)&&(w=!0),E.set(e.index,s),D.set(e.index,l),(e.leaving?t<e.start+e.duration-1e-7:!e.entering||t>=e.start-1e-7)&&n.add(e.index)}(n.size!==O.size||[...n].some(e=>!O.has(e)))&&(O=n,T=null,w=!0)}function F(e,o,c,l,u=!1){if(!Number.isInteger(e)||e<3||e>9)throw RangeError(`Battery count must be an integer from 3 to 9.`);if(P(l),!u&&S===e&&x===o&&C===c)return;let d=S,f=x;S=e,x=o,C=c;let p=new Set(M().map(e=>e.index)),m=!!k?.replay||A;if(A=!1,!C||!x||!f){k=null,O=p;for(let e of t)E.set(e.index,x&&e===r?N(S):0),D.set(e.index,0)}else if(u)O=p,k={tracks:M().map((e,t)=>({index:e.index,start:t*35,duration:300,lowY:(e===r?N(S):0)+(t?n*2.2:0),highY:e===r?N(S):0,lowX:0,highX:0})),duration:300+(S-1)*35,time:0,at:l,running:!0,replay:!0},P(l);else{if(m)for(let e of t)E.set(e.index,e===r?N(d):0),D.set(e.index,0);let e=E.get(r.index),o=N(S),c=o>=e,u=[],f=(e,t)=>{let n=!k?.replay&&k?.tracks.find(t=>t.index===e);return!n||n.highX!==t||n.lowX===t||k.time<n.start?null:{...n,start:n.start-k.time}},h=[];for(let e of t.slice(1,8).reverse()){if(!O.has(e.index)||p.has(e.index))continue;let t=D.get(e.index),n=t>0?1-s(j(1-t/a)):0;if(n>.999)continue;let o=e.bounds.maxY+E.get(e.index)-i-r.bounds.minY;h.push({part:e,top:o,phase:n,remaining:150*(1-n)})}let g=e,_=0,v=0,y=(t,r)=>{g=Math.min(e,h[t].top),_=r,v=_+150*j((e-g)/n),h.forEach((e,n)=>{e.reach=n>t&&g>o?s(j((g-e.top)/(g-o))):0,n>=t&&(v=Math.max(v,e.remaining-e.reach*600))})};h.length&&(y(0,0),e-g<n*.05&&h.length>1&&v>h[0].remaining+1&&y(1,h[0].remaining));let b=300;for(let{remaining:e,reach:t}of h)t>0&&(b=Math.max(b,Math.min(600,(e-v)/t)));v>0&&u.push({index:r.index,start:_,duration:v-_,lowY:e,highY:g,lowX:0,highX:0}),u.push({index:r.index,start:v,duration:b,lowY:g,highY:o,lowX:0,highX:0,after:v>0});let x=v+b;for(let{part:e,phase:t,remaining:n,reach:r}of h){let i=t>0?0:Math.max(0,v+r*b-n),o=E.get(e.index);u.push({index:e.index,start:i-t*150,duration:150,lowY:o,highY:o,lowX:0,highX:a,leaving:!0})}for(let n of t.slice(0,8)){let t=O.has(n.index);if(!p.has(n.index))continue;let l=!t,d=t?D.get(n.index):a,m=E.get(n.index);if(l||d!==0){let t=n.bounds.maxY-i,p=l&&c&&o>e?s(j((t-r.bounds.minY-e)/(o-e)))*300:0,m=f(n.index,0)||{index:n.index,start:p,duration:Math.max(1,150*j(d/a)),lowY:0,highY:0,lowX:d,highX:0};u.push({...m,entering:l}),x=Math.max(x,m.start+m.duration)}else u.push({index:n.index,start:0,duration:300,lowY:m,highY:0,lowX:0,highX:0})}k={tracks:u,duration:x,time:0,at:l,running:!0},P(l)}T=null,w=!0}function I(){let n=[...O].reduce((e,t)=>e|1<<t,0);if(h.has(n)){T=h.get(n),h.delete(n),h.set(n,T);return}let r=p.filter(e=>O.has(e.index)),i=m.filter(e=>O.has(e.index)),a=r.reduce((e,t)=>e+t.end-t.start,0),o=i.reduce((e,t)=>e+t.end-t.start,0);T={};for(let e of[`positions`,`normals`,`colors`])T[e]=new Float32Array(a);for(let e of[`isGreen`,`fillPattern`,`objectIndex`])T[e]=new Float32Array(a/3);T.linePositions=new Float32Array(o),T.lineIsGreen=Array(o/6),T.lineObjectIndex=new Int32Array(o/6),T.vertexRanges=[],T.lineRanges=[];let s=0;for(let t of r){let n=t.end-t.start;for(let n of[`positions`,`normals`,`colors`])T[n].set(e[n].subarray(t.start,t.end),s);for(let n of[`isGreen`,`fillPattern`,`objectIndex`])T[n].set(e[n].subarray(t.start/3,t.end/3),s/3);T.vertexRanges.push({index:t.index,start:s,end:s+n}),s+=n}s=0;for(let t of i){let n=t.end-t.start;T.linePositions.set(e.linePositions.subarray(t.start,t.end),s);for(let r=0;r<n/6;r++)T.lineIsGreen[s/6+r]=e.lineIsGreen[t.start/6+r];T.lineObjectIndex.fill(t.index,s/6,(s+n)/6),T.lineRanges.push({index:t.index,start:s,end:s+n}),s+=n}T.basePositions=T.positions.slice(),T.baseLinePositions=T.linePositions.slice(),T.appliedOffsets=new Float64Array(t.length).fill(NaN),T.appliedSlides=new Float64Array(t.length).fill(NaN),h.set(n,T),h.size>16&&h.delete(h.keys().next().value)}return{configure:F,spreadApart(e){x&&(k=null,A=!0,O=new Set(M().map(e=>e.index)),M().forEach((t,n)=>{E.set(t.index,(t===r?N(S):0)+n*e),D.set(t.index,0)}),T=null,w=!0)},settle(e,t=800){A&&(A=!1,k={tracks:M().map(e=>({index:e.index,start:0,duration:t,lowY:E.get(e.index),highY:e===r?N(S):0,lowX:0,highX:0,settle:!0})),duration:t,time:0,at:e,running:!0,replay:!0},P(e),w=!0)},update(n){if(!w&&!k?.running)return null;P(n),T||I();let r=T!==_,i=!1,o=!1;for(let n of t){let t=n.index,r=E.get(t),i=D.get(t);if(g[t]=+(T.appliedOffsets[t]!==r||T.appliedSlides[t]!==i),T.appliedOffsets[t]=r,T.appliedSlides[t]=i,y[t]!==r||b[t]!==i){let n=e.objects[t];v[t]={...n,center:[n.center[0]+i,n.center[1]+r,n.center[2]],bounds:{...n.bounds,minX:n.bounds.minX+i,maxX:n.bounds.maxX+i,minY:n.bounds.minY+r,maxY:n.bounds.maxY+r}},y[t]=r,b[t]=i,o=!0}}for(let e of T.vertexRanges){if(!g[e.index])continue;i=!0;let t=T.appliedSlides[e.index],n=T.appliedOffsets[e.index];for(let r=e.start;r<e.end;r+=3)T.positions[r]=T.basePositions[r]+t,T.positions[r+1]=T.basePositions[r+1]+n}for(let e of T.lineRanges){if(!g[e.index])continue;let t=T.appliedSlides[e.index],n=T.appliedOffsets[e.index];for(let r=e.start;r<e.end;r+=3)T.linePositions[r]=T.baseLinePositions[r]+t,T.linePositions[r+1]=T.baseLinePositions[r+1]+n}if(!w&&!r&&!i&&!o)return null;w=!1,_=T;let s=[];for(let e of t){let t=1-j(D.get(e.index)/a);O.has(e.index)&&t<1&&s.push({index:e.index,opacity:t})}return{...T,objects:v.slice(),membershipChanged:r,fades:s}},get activeNames(){return M().map(e=>e.name)},get centerOffset(){return x?N(S)/2:0},get animating(){return!!k?.running}}}function t(e){let t={v:0,vt:0,vn:0};return e.map(e=>{let n={v:0,vt:0,vn:0},r=e.split(`
`).map(e=>{let[r,...i]=e.trim().split(/\s+/);return r in n&&n[r]++,r===`f`?`f ${i.map(e=>e.split(`/`).map((e,n)=>e>0?+e+t[[`v`,`vt`,`vn`][n]]:e).join(`/`)).join(` `)}`:e});for(let e in n)t[e]+=n[e];return r.join(`
`)}).join(`
`)}function n(e){let t=e.objects.map((e,t)=>({...e,index:t,model:/^(EP(?:5|12))_Side-by-Side_-_Module_0[1-4]$/.exec(e.name)?.[1]}));if(!t.length||t.some(e=>!e.model))return null;let n=[...new Set(t.map(e=>e.model))].map(e=>{let n=t.filter(t=>t.model===e).sort((e,t)=>e.bounds.minZ-t.bounds.minZ),r=n.length===4?n[1].center[2]-n[0].center[2]:0,i=Object.fromEntries([`X`,`Y`,`Z`].flatMap(e=>[[`min${e}`,Math.min(...n.map(t=>t.bounds[`min${e}`]))],[`max${e}`,Math.max(...n.map(t=>t.bounds[`max${e}`]))]]));return{model:e,pitch:r,bounds:i,center:[`X`,`Y`,`Z`].map(e=>(i[`min${e}`]+i[`max${e}`])/2),parts:n.map((e,t)=>({...e,order:t,pitch:r}))}});if(n.some(e=>!(e.pitch>0)))return null;let r=n.flatMap(e=>e.parts),i=(Math.min(...n.map(e=>e.bounds.minZ))+Math.max(...n.map(e=>e.bounds.maxZ)))/2,a=4.5*Math.max(...n.map(({bounds:e})=>Math.hypot(e.maxX-e.minX,e.maxY-e.minY,e.maxZ-e.minZ))),o=new Float64Array(e.objects.length),s=[...n].sort((e,t)=>e.center[2]-t.center[2]),c=s[0].center[2];s.forEach((e,t)=>{let n=c+t*a-e.center[2];e.center[2]+=n,e.bounds.minZ+=n,e.bounds.maxZ+=n;for(let t of e.parts)o[t.index]=n});let l=new Float64Array(e.objects.length);for(let e of r)l[e.index]=e.pitch*1.4;let u=n[0],d=e=>Math.max(0,Math.min(1,e)),f=e=>Math.sin(Math.PI*e/2),p=e=>e<.5?8*e**4:1-(-2*e+2)**4/2,m=(e,t)=>`${e[t]},${e[t+1]},${e[t+2]}`,h=new Map;e.objectIndex.forEach((t,n)=>h.set(m(e.positions,n*3),t));let g=[];for(let t=0;t<e.linePositions.length;t+=6)g.push(h.get(m(e.linePositions,t)));if(g.some(e=>e===void 0))return null;let _=4,v=!1,y=!0,b=!0,x=!1,S=new Set(r.map(e=>e.index)),C=[],w=null,T=new Float64Array(e.objects.length),E=new Float64Array(e.objects.length),D=()=>v?n.flatMap(e=>e.parts.slice(0,_)):r;function O(e){let t=[];for(let n of C){let r=d((e-n.at-n.delay)/n.duration),i=n.settle?p(r):n.leaving?1-f(1-r):f(r),a=n.from+(n.to-n.from)*i,o=n.spread?T:E;a!==o[n.index]&&(b=!0),o[n.index]=a,n.entering&&e>=n.at+n.delay&&!S.has(n.index)&&(S.add(n.index),w=null,b=!0),r===1&&n.leaving&&(S.delete(n.index),w=null,b=!0),r<1&&t.push(n)}C=t}function k(e,t,r,i,a=!1){if(!Number.isInteger(e)||e<1||e>4)throw RangeError(`Battery count must be an integer from 1 to 4.`);if(O(i),!a&&e===_&&t===v&&r===y)return;let o=v,s=x||C.some(e=>e.spread);_=e,v=t,y=r,x=!1;let c=new Set(D().map(e=>e.index));if(!y||!v||!o)S=c,T.fill(0),E.fill(0),C=[];else if(a)S=c,E.fill(0),C=D().map(e=>(T[e.index]=e.order?e.pitch*2.2:0,{index:e.index,at:i,delay:e.order*35,duration:300,from:T[e.index],to:0,spread:!0}));else{s&&(T.fill(0),E.fill(0));let e=new Map(s?[]:C.map(e=>[e.index,e]));C=[];let t=(t,n)=>{let r=null;for(let a of t){let t=a.index,o=S.has(t),s=n?l[t]:0,c=e.get(t),u;if(c&&c.to===s)u=c;else{let e=o?E[t]:l[t];E[t]=e;let a=Math.max(1,150*Math.abs(s-e)/l[t]);u={index:t,at:i,delay:(r?Math.max(i,r.at+r.delay+35,r.at+r.delay+r.duration-a):i)-i,duration:a,from:e,to:s,entering:!n&&!o,leaving:n}}C.push(u),r=u}};for(let e of n)t(e.parts.filter(e=>S.has(e.index)&&!c.has(e.index)).reverse(),!0),t(e.parts.filter(e=>c.has(e.index)&&(!S.has(e.index)||E[e.index]!==0)),!1)}w=null,b=!0}function A(){let t=(e,t)=>{let n=[],i=0;for(let a of r)if(S.has(a.index))for(let r=0;r<e.length;){let o=e[r],s=r+1;for(;s<e.length&&e[s]===o;)s++;if(o===a.index){let e=(s-r)*t;n.push({index:o,sourceStart:r*t,start:i,end:i+e}),i+=e}r=s}return{ranges:n,length:i}},n=t(e.objectIndex,3),i=t(g,6);w={vertexRanges:n.ranges,lineRanges:i.ranges};for(let e of[`positions`,`normals`,`colors`])w[e]=new Float32Array(n.length);for(let e of[`isGreen`,`fillPattern`,`objectIndex`])w[e]=new Float32Array(n.length/3);w.linePositions=new Float32Array(i.length),w.lineIsGreen=[];for(let t of n.ranges){let n=t.end-t.start;for(let r of[`positions`,`normals`,`colors`])w[r].set(e[r].subarray(t.sourceStart,t.sourceStart+n),t.start);for(let r of[`isGreen`,`fillPattern`,`objectIndex`])w[r].set(e[r].subarray(t.sourceStart/3,(t.sourceStart+n)/3),t.start/3)}for(let t of i.ranges){let n=t.end-t.start;w.linePositions.set(e.linePositions.subarray(t.sourceStart,t.sourceStart+n),t.start);for(let r=0;r<n/6;r++)w.lineIsGreen[t.start/6+r]=e.lineIsGreen[t.sourceStart/6+r]}}return{configure:k,spreadApart(e,t){if(v){C=[],x=!0,E.fill(0),S=new Set(D().map(e=>e.index));for(let n of D())T[n.index]=!t||n.model===t?n.order*e:0;w=null,b=!0}},settle(e,t=800,n=0){x&&(x=!1,C=D().map(r=>({index:r.index,at:e,delay:n,duration:t,from:T[r.index],to:0,settle:!0,spread:!0})),b=!0)},update(t){if(O(t),!b)return null;let n=!w;w||A();for(let[t,n,r]of[[w.vertexRanges,w.positions,e.positions],[w.lineRanges,w.linePositions,e.linePositions]])for(let e of t)for(let t=e.start;t<e.end;t+=3){let i=e.sourceStart+t-e.start;n[t]=r[i]+E[e.index],n[t+2]=r[i+2]+o[e.index]+T[e.index]}b=!1;let r=e.objects.map((e,t)=>({...e,center:[e.center[0]+E[t],e.center[1],e.center[2]+o[t]+T[t]],bounds:{...e.bounds,minX:e.bounds.minX+E[t],maxX:e.bounds.maxX+E[t],minZ:e.bounds.minZ+o[t]+T[t],maxZ:e.bounds.maxZ+o[t]+T[t]}})),i=[...S].filter(e=>E[e]>0).map(e=>({index:e,opacity:1-d(E[e]/l[e])}));return{...w,objects:r,fades:i,membershipChanged:n}},get activeNames(){return D().map(e=>e.name)},focus(e){u=n.find(t=>t.model===e)??u},get focusedModel(){return u.model},get frames(){return n.map(({model:e,bounds:t,center:n})=>({model:e,bounds:t,center:n}))},get centerOffset(){return u.center[2]-i+(v?(_-4)*u.pitch/2:0)},get animating(){return C.length>0}}}function r(r){let i=Math.min(window.devicePixelRatio||1,2),a=r.teardown,o={getItem:()=>null,setItem(){},removeItem(){}},s=r.canvas,c=r.sideways,l=c?1:3,u=c?4:9,d=`iconMosaic.slider.`;function f(e,t){let n=o.getItem(d+e);return n===null?t:Number(n)}function p(e,t){o.setItem(d+e,String(t))}let m=`iconMosaic.cubeSizeDefaultResetV1`;o.getItem(m)||(o.removeItem(`iconMosaic.slider.cubeSize`),o.setItem(m,`1`));let h=`iconMosaic.dotDefaultsResetV2`;o.getItem(h)||(o.removeItem(`iconMosaic.slider.dotFrequency`),o.removeItem(`iconMosaic.slider.dotSize`),o.setItem(h,`1`));let g=`iconMosaic.plusDefaultsResetV2`;o.getItem(g)||(o.removeItem(`iconMosaic.slider.plusFrequency`),o.removeItem(`iconMosaic.slider.plusSize`),o.setItem(g,`1`));let _=`iconMosaic.modelOffsetDefaultResetV1`;o.getItem(_)||(o.removeItem(`iconMosaic.slider.modelOffsetX`),o.removeItem(`iconMosaic.slider.modelOffsetY`),o.removeItem(`iconMosaic.slider.modelOffsetZ`),o.setItem(_,`1`));let v=f(`pulseWidth`,1)/100,y=f(`flowSpeed`,50),b=f(`flowCoreLength`,60),x=f(`flowTailLength`,160),S=f(`flowTailFalloff`,1),C=f(`flowPulseFrequency`,5),w=f(`cubeSize`,100),T=w/100;function E(e){let t=Math.max(1,Math.min(1e3,e)),n=T;if(w=t,T=t/100,n>0&&T!==n){let e=T/n;U=G(U*e),gt=G(gt*e),W=G(W*e)}return t}function D(e){let t=E(e);return p(`cubeSize`,t),Y(),t}let O=f(`lineFrequency`,40),k=f(`dotFrequency`,4),A=f(`dotSize`,5),j=f(`plusFrequency`,9),M=f(`plusSize`,5);o.getItem(`iconMosaic.shaderTheme`);let N=`light`;function P(){return`lightAzimuthLight`}function F(){return`lightElevationLight`}function I(){return`lightIntensityLight`}function ee(){return 110}function te(){return 33}function ne(){return 185}let re=f(P(),ee()),ie=f(F(),te()),ae=f(I(),ne()),oe=o.getItem(`iconMosaic.blueprint`),se=oe===null||oe===`true`,L=s.getContext(`webgl`,{antialias:!0});{if(!L)throw Error(`WebGL is unavailable.`);let e=[`Buffer`,`Program`,`Shader`],t=[];for(let n of e)L[`create${n}`]=(...e)=>{let r=WebGLRenderingContext.prototype[`create${n}`].apply(L,e);return t.push([n,r]),r};a.signal.addEventListener(`abort`,()=>{for(let[e,n]of t)L[`delete${e}`](n);for(let t of e)delete L[`create${t}`]})}L.getExtension(`OES_standard_derivatives`);function ce(e,t){let n=L.createShader(e);if(L.shaderSource(n,t),L.compileShader(n),!L.getShaderParameter(n,L.COMPILE_STATUS))throw Error(L.getShaderInfoLog(n));return n}let R=L.createProgram();if(L.attachShader(R,ce(L.VERTEX_SHADER,`
  attribute vec3 aPosition;
  attribute vec3 aNormal;
  attribute vec3 aColor;
  attribute float aIsGreen;
  attribute float aFlowCoord;
  // The world-space arc length of whichever flow path this vertex was
  // assigned to (aFlowCoord's normalizing masterTotalLen, carried through
  // unnormalized) — lets the fragment shader convert the tail/core reach
  // back out of aFlowCoord's per-path-normalized space into an absolute
  // distance, so their real lengths stay the same regardless of how long
  // the specific arrow is. See recomputeModelFlowCoords/MODEL_FLOW_REFERENCE_LENGTH.
  attribute float aFlowPathLen;
  // Which technical-fill pattern (if any) this vertex's face uses: 0 = none,
  // 1 = hatch lines, 2 = dots, 3 = plus marks — see materialFillPatternId,
  // which maps a Blender material name to one of these. A single float
  // (rather than a separate boolean per pattern) keeps this to one
  // attribute/buffer regardless of how many fill patterns exist.
  attribute float aFillPattern;
  uniform mat4 uModelView;
  uniform mat4 uProjection;
  varying vec3 vNormal;
  varying vec3 vColor;
  varying float vIsGreen;
  varying float vFlowCoord;
  varying float vFlowPathLen;
  varying vec3 vPosition;
  varying float vFillPattern;
  void main() {
    gl_Position = uProjection * uModelView * vec4(aPosition, 1.0);
    // Object-space normal (no model rotation applied) so the light stays
    // fixed relative to the model instead of the camera as it's dragged.
    vNormal = aNormal;
    vColor = aColor;
    vIsGreen = aIsGreen;
    vFlowCoord = aFlowCoord;
    vFlowPathLen = aFlowPathLen;
    // Object-space position, same reasoning as vNormal above: the fill
    // pattern it drives (see CUBE_FRAGMENT_SHADER) needs to stay fixed to
    // the model rather than swim as the camera orbits.
    vPosition = aPosition;
    vFillPattern = aFillPattern;
  }
`)),L.attachShader(R,ce(L.FRAGMENT_SHADER,`
  #extension GL_OES_standard_derivatives : enable
  precision mediump float;
  varying vec3 vNormal;
  varying vec3 vColor;
  varying float vIsGreen;
  varying float vFlowCoord;
  varying float vFlowPathLen;
  varying vec3 vPosition;
  varying float vFillPattern;
  uniform vec3 uLightDir;
  uniform float uLightIntensity;
  uniform bool uBlueprint;
  uniform vec3 uBlueprintFillColor;
  uniform vec3 uBlueprintFillColorGreen;
  uniform bool uFlowActive;
  // uFlowWorldPos is a shared, ever-growing world-space distance at the
  // *reference* speed (see flowSpeedWorldPerMs in renderCubeFrame) — the
  // speed a MODEL_FLOW_REFERENCE_LENGTH-long (uFlowReferenceLength) arrow
  // actually travels at. flowPulseIntensity below scales it per-vertex by
  // sqrt(vFlowPathLen / uFlowReferenceLength) so longer arrows move faster
  // than shorter ones — not proportionally faster (that would make every
  // arrow's lap TIME constant again, i.e. back in sync), just enough that
  // long arrows read livelier while still drifting out of phase with short
  // ones over time. The scaled result is then wrapped by this vertex's own
  // vFlowPathLen to get *this* arrow's own 0-1 travel-loop progress, and
  // this arrow's other concurrent pulses (see uFlowPulseDensity below) are
  // spaced out from that using uFlowRange/uFlowPad — all per-vertex since
  // pulse count, speed, and lap time all depend on vFlowPathLen.
  uniform float uFlowWorldPos;
  uniform float uFlowReferenceLength;
  uniform float uFlowRange;
  uniform float uFlowPad;
  // Pulses-per-MODEL_FLOW_REFERENCE_LENGTH-of-path-length (see
  // FLOW_PULSE_FREQUENCY_MIN/flowPulseDensity in renderCubeFrame) —
  // multiplied by this vertex's own vFlowPathLen in flowPulseIntensity
  // below to get that specific arrow's own pulse count, so a longer arrow
  // carries proportionally more concurrent pulses instead of the same
  // handful stretched thin over more physical distance. GLSL ES 1.00 loops
  // need a constant upper bound, so MAX_FLOW_PULSES caps the loop and each
  // arrow's own computed count is checked with a dynamic break. Raised from
  // the old 8 (which matched FLOW_PULSE_FREQUENCY_MAX, but that's the
  // density baseline for a MODEL_FLOW_REFERENCE_LENGTH-long arrow, not a
  // ceiling on any specific arrow's own count — a ~29-unit arrow at the
  // default "Pulse frequency" already computes ~49) so long arrows keep
  // scaling instead of saturating well before the default density would
  // otherwise allow — dialed back down from a first pass at 64, which read
  // as too dense/costly on the longest arrows. Each extra unit here is
  // extra worst-case per-fragment cost (one more possible loop
  // iteration/exp() pair), so don't raise this far past what the longest
  // arrows actually need.
  const int MAX_FLOW_PULSES = 32;
  uniform float uFlowPulseDensity;
  uniform float uFlowSigma;
  uniform vec3 uFlowColor;
  uniform vec3 uFlowCoreColor;
  // Absolute world-space head/core/tail reach (not a fraction of any one
  // path's own length — see MODEL_FLOW_REFERENCE_LENGTH) so all three stay
  // the same physical size on every arrow regardless of how long it is drawn.
  uniform float uFlowHeadWorldSigma;
  uniform float uFlowCoreWorldSigma;
  uniform float uFlowTailWorldSigma;
  uniform float uFlowTailFalloffExponent;
  uniform bool uFlowTailVisible;
  uniform vec3 uHatchLineColor;
  uniform float uLineFrequency;
  uniform float uDotFrequency;
  uniform float uDotRadius;
  uniform float uPlusFrequency;
  uniform float uPlusArmHalf;
  uniform float uPlusThickness;
  // 1 everywhere except battery slaves fading in or out of the stack (see
  // drawBatteryRanges), which draw as their own blended batch.
  uniform float uOpacity;

  // Shared by all three fill patterns below (lines/dots/plus): projects
  // object-space position onto the two axes spanning the face (dropping
  // whichever axis the normal points along), sampled in object space so the
  // pattern stays put on the face as the model rotates instead of swimming
  // (screen-space would be simpler but reads as "wrong" the moment the
  // camera moves) — and so spacing is consistent regardless of which cube
  // face, or which arbitrary custom-model face, is flagged.
  vec2 fillPatternUV(vec3 pos, vec3 normal) {
    vec3 an = abs(normal);
    if (an.x >= an.y && an.x >= an.z) return pos.yz;
    if (an.y >= an.x && an.y >= an.z) return pos.xz;
    return pos.xy;
  }

  // Edge thickness/softness shared by all three patterns, and the shared
  // anti-moire fallback: derived from the screen-space gradient of each
  // pattern's own "distance to feature" value rather than a fixed fraction
  // of the period, so every pattern renders at a constant ~1 device pixel
  // — matching the wireframe overlay (gl.LINES at the default 1px width) —
  // regardless of how the face is scaled/tilted/zoomed. Below
  // MIN_RESOLVED_PERIOD_PX screen pixels per period, the pattern has more
  // than one repeat per pixel — under-sampled, so a crisp per-fragment test
  // aliases into shimmering moire as the surface (or the camera orbiting
  // it) tilts the face toward grazing incidence, where foreshortening keeps
  // shrinking the on-screen period. Standard fix (used for procedural
  // grids/checkers under minification): once the period drops close to or
  // below this, fade to the pattern's flat average coverage instead of
  // trying to resolve individual features the pixel grid can't represent.
  const float FILL_EDGE_HALF_WIDTH_PX = 1.0;
  const float FILL_MIN_RESOLVED_PERIOD_PX = 3.0;
  const float FILL_ALIASED_PERIOD_PX = 1.0;

  // Diagonal hatch lines. Uses the exact gradient length (dFdx/dFdy
  // combined via Pythagoras) rather than fwidth's cheaper
  // abs(dFdx)+abs(dFdy) approximation — fwidth overestimates the gradient
  // except when the line runs exactly along the x or y screen axis, so it
  // was making the line's rendered width (and thus its antialiasing)
  // inconsistent — thinner/rougher-looking — at the diagonal angles most
  // hatch lines actually run at.
  float hatchLinesMask(vec3 pos, vec3 normal) {
    vec2 uv = fillPatternUV(pos, normal);
    float diag = (uv.x + uv.y) * uLineFrequency;
    float gradLen = length(vec2(dFdx(diag), dFdy(diag)));
    float phase = fract(diag);
    float distToLine = min(phase, 1.0 - phase) / max(gradLen, 1e-6);
    float crispLine = 1.0 - smoothstep(0.0, FILL_EDGE_HALF_WIDTH_PX, distToLine);
    float periodPx = 1.0 / max(gradLen, 1e-6);
    float coverage = clamp((2.0 * FILL_EDGE_HALF_WIDTH_PX) / max(periodPx, 1e-3), 0.0, 1.0);
    float resolved = smoothstep(FILL_ALIASED_PERIOD_PX, FILL_MIN_RESOLVED_PERIOD_PX, periodPx);
    return mix(coverage, crispLine, resolved);
  }

  // Small filled circles on a regular grid, one per uDotFrequency cell.
  // uDotRadius is a fraction of the cell period (so dot size scales with
  // spacing, like a real screen-printed dot pattern) rather than a fixed
  // size — user-adjustable via the "Dot size" slider.
  float dotsMask(vec3 pos, vec3 normal) {
    vec2 uv = fillPatternUV(pos, normal) * uDotFrequency;
    vec2 cell = fract(uv) - 0.5;
    float dist = length(cell);
    float gradLen = length(vec2(dFdx(dist), dFdy(dist)));
    float distPx = (dist - uDotRadius) / max(gradLen, 1e-6);
    float crispDot = 1.0 - smoothstep(-FILL_EDGE_HALF_WIDTH_PX, FILL_EDGE_HALF_WIDTH_PX, distPx);
    float periodPx = 1.0 / max(gradLen, 1e-6);
    float flatCoverage = clamp(3.14159265 * uDotRadius * uDotRadius, 0.0, 1.0);
    float resolved = smoothstep(FILL_ALIASED_PERIOD_PX, FILL_MIN_RESOLVED_PERIOD_PX, periodPx);
    return mix(flatCoverage, crispDot, resolved);
  }

  // Small "+" marks on a regular grid, one per uPlusFrequency cell — a
  // union of a horizontal and a vertical bar (a cheap box-distance cross,
  // not an exact Euclidean SDF, but sufficient at the thin scale these
  // render at). uPlusArmHalf/uPlusThickness are fractions of the cell
  // period, same reasoning as uDotRadius above — user-adjustable via the
  // "Plus size" slider (thickness follows arm length at a fixed ratio, see
  // PLUS_THICKNESS_RATIO in renderCubeFrame, so it keeps reading as a "+").
  float plusMask(vec3 pos, vec3 normal) {
    vec2 uv = fillPatternUV(pos, normal) * uPlusFrequency;
    vec2 cell = fract(uv) - 0.5;
    float distH = max(abs(cell.y) - uPlusThickness, abs(cell.x) - uPlusArmHalf);
    float distV = max(abs(cell.x) - uPlusThickness, abs(cell.y) - uPlusArmHalf);
    float dist = min(distH, distV);
    float gradLen = length(vec2(dFdx(dist), dFdy(dist)));
    float distPx = dist / max(gradLen, 1e-6);
    float crispPlus = 1.0 - smoothstep(-FILL_EDGE_HALF_WIDTH_PX, FILL_EDGE_HALF_WIDTH_PX, distPx);
    float periodPx = 1.0 / max(gradLen, 1e-6);
    float flatCoverage = clamp(8.0 * uPlusArmHalf * uPlusThickness - 4.0 * uPlusThickness * uPlusThickness, 0.0, 1.0);
    float resolved = smoothstep(FILL_ALIASED_PERIOD_PX, FILL_MIN_RESOLVED_PERIOD_PX, periodPx);
    return mix(flatCoverage, crispPlus, resolved);
  }
  // Traveling energy-pulse intensity along a user-drawn arrow, restricted to
  // green (flagged) parts that some arrow actually touches — driven by a 3D
  // arc-length coordinate (aFlowCoord). Vertices on a green part no arrow was
  // ever drawn on get a negative aFlowCoord (see recomputeModelFlowCoords) so
  // they never light up, rather than defaulting to 0 and falsely flashing
  // whenever the pulse happens to pass near the start of some other part's
  // arrow.
  //
  // Comet shape rather than a symmetric Gaussian band: d>0 is ahead of the
  // pulse center in the direction of travel (increasing vFlowCoord, same
  // direction uFlowPulseCenter sweeps over time) — the comet's bright head,
  // narrow and fixed like the tail/core below, so it cuts off sharply just
  // past center. d<0 is behind — already passed, fading — so it uses
  // uFlowTailWorldSigma (user-adjustable "Tail length", an absolute
  // world-space distance via dArc below so it doesn't grow/shrink with this
  // specific arrow's own length) for its reach, and uFlowTailFalloffExponent
  // ("Tail falloff") for the curve's shape independent of that reach: 2.0
  // matches a plain Gaussian, higher stays near full brightness longer then
  // drops more sharply near the tail's end, lower behaves more like a thin
  // exponential streak. On top of both sits a second, much tighter "hot
  // core" lobe (uFlowCoreWorldSigma, "Core length" — symmetric, and, like
  // the head and tail, an absolute world-space size rather than a fraction
  // of this arrow's own length, so it doesn't grow/shrink with path length
  // either) adding extra brightness concentrated right at the head, so it
  // reads as a distinct bright point instead of just the front edge of a
  // flat-topped band.
  // 1.5 read fine back when the (now-removed) bloom pass pre-boosted
  // uFlowColor by up to 4x before blurring it — blur then spread that
  // extra brightness into an obviously bigger halo, so even a modest
  // additive nudge here translated into a dramatic glow change. Rendered
  // directly on the model with no blur, 1.5x on top of an already-bright
  // pulse barely moved the on-screen result, which is why widening "Core
  // length" only ever looked subtle after bloom was dropped. Raised to
  // compensate so the slider still has real range on its own.
  const float FLOW_COMET_CORE_BOOST = 4.5;
  // Every sigma below gets floored to cover at least this many screen
  // pixels — same fix as hatchLinesMask/dotsMask/plusMask above, applied to
  // the pulse instead of a fill pattern. vFlowCoord is a 0-1 fraction of
  // this specific arrow's own path length, so how many screen pixels one
  // unit of it spans isn't fixed — it shrinks the same way any world-space
  // length does when zoomed out, but *also* when the path's local direction
  // swings toward/away from the camera (orthographic projection collapses
  // length-along-view-direction to near nothing, independent of zoom — a
  // ground-parallel tube keeps its full length on screen from a bird's-eye
  // view, but a vertical one is now pointing straight at the camera). Once
  // a sigma that's a fixed WORLD size gets squeezed into a fraction of a
  // pixel by either effect, it can't be sampled correctly, which is exactly
  // the blocky/double-lobed look reported at steep angles and far zoom.
  // Widening the sigma here keeps the pulse resolvable to begin with.
  const float FLOW_MIN_SIGMA_PX = 1.0;
  // Returns (headTailIntensity, coreIntensity) separately rather than one
  // combined scalar — main() below colors them independently (uFlowColor
  // for the head/tail body, uFlowCoreColor for the hot core lobe), so the
  // core reads as a visibly distinct hot spot instead of just extra
  // brightness in the same color.
  vec2 flowPulseIntensity() {
    if (!(uBlueprint && uFlowActive && vIsGreen > 0.5 && vFlowCoord >= 0.0)) return vec2(0.0);
    float coordGradLen = length(vec2(dFdx(vFlowCoord), dFdy(vFlowCoord)));
    float minCoordSigma = coordGradLen * FLOW_MIN_SIGMA_PX;
    // minCoordSigma is in vFlowCoord's own 0-1-per-path units — scale it by
    // vFlowPathLen (same conversion dArc below uses) to floor tail/core
    // sigma in the world-space units they actually need to be in.
    float minWorldSigma = minCoordSigma * vFlowPathLen;
    // This arrow's own travel-loop progress. uFlowWorldPos is a shared
    // absolute world-space distance at the *reference* speed (see
    // flowSpeedWorldPerMs in renderCubeFrame); sqrt(lapLen/uFlowReferenceLength)
    // scales that up for longer arrows (down for shorter ones) so longer
    // arrows move faster in absolute terms, without scaling exactly enough
    // to keep every arrow's lap TIME equal — arrows still drift out of
    // phase with each other over time, which is intentional (see the file
    // header comment above "3D flow arrows"). The result is then wrapped by
    // *this* vertex's own vFlowPathLen to get this arrow's 0-1 progress.
    // GLSL's mod() always lands in [0, lapLen) for lapLen > 0, unlike JS's
    // %, so no separate handling for negative input is needed here.
    float lapLen = max(vFlowPathLen, 1e-6);
    float arrowWorldPos = uFlowWorldPos * sqrt(lapLen / uFlowReferenceLength);
    float basePulseCenter = -uFlowPad + mod(arrowWorldPos, lapLen) / lapLen * uFlowRange;
    // This arrow's own pulse count — longer arrows (bigger vFlowPathLen)
    // get proportionally more, see uFlowPulseDensity above. Floored to the
    // nearest whole pulse and never less than 1, so even a short arrow
    // always carries at least the primary pulse.
    int pulseCount = int(clamp(floor(uFlowPulseDensity * vFlowPathLen + 0.5), 1.0, float(MAX_FLOW_PULSES)));
    float spacing = uFlowRange / float(pulseCount);
    float totalBase = 0.0;
    float totalCore = 0.0;
    for (int i = 0; i < MAX_FLOW_PULSES; i++) {
      if (i >= pulseCount) break;
      // Extra pulses trail the primary one at even offsets around the
      // shared travel loop, each wrapped back into [-uFlowPad, uFlowRange -
      // uFlowPad) so they fade in/out at the loop's ends just like the
      // primary pulse instead of popping when an offset center wanders past
      // a boundary. GLSL's mod() (x - y*floor(x/y)) always lands in
      // [0, uFlowRange) for uFlowRange > 0, unlike JS's %, so no separate
      // handling for negative input is needed here.
      float shifted = basePulseCenter - float(i) * spacing + uFlowPad;
      float wrapped = mod(shifted, uFlowRange);
      float d = vFlowCoord - (wrapped - uFlowPad);
      // World-space distance from the pulse center — unlike d itself (a
      // fraction of this specific arrow's own length), this is the same
      // physical distance meaning on every arrow, which is what lets the
      // core lobe below stay a fixed size regardless of path length.
      float dArc = abs(d) * vFlowPathLen;
      float base;
      if (d > 0.0) {
        float sigma = max(uFlowHeadWorldSigma, minWorldSigma);
        base = exp(-(dArc * dArc) / (2.0 * sigma * sigma));
      } else {
        float tailSigma = max(max(uFlowTailWorldSigma, minWorldSigma), 1e-6);
        base = uFlowTailVisible ? exp(-0.5 * pow(dArc / tailSigma, uFlowTailFalloffExponent)) : 0.0;
      }
      float coreSigma = max(uFlowCoreWorldSigma, minWorldSigma);
      float core = exp(-(dArc * dArc) / (2.0 * coreSigma * coreSigma));
      totalBase += base;
      totalCore += core * FLOW_COMET_CORE_BOOST;
    }
    return vec2(totalBase, totalCore);
  }

  void main() {
    float diff = max(dot(normalize(vNormal), normalize(uLightDir)), 0.0) * uLightIntensity;
    float brightness = 0.2 + diff * 0.8;
    // Blueprint mode: ignore the material/cube color entirely and shade a
    // flat fill instead (navy, or green for green-material parts), dimmed
    // further so the wireframe overlay (drawn in a separate pass) reads as
    // the bright part of the look.
    vec3 base = uBlueprint ? (vIsGreen > 0.5 ? uBlueprintFillColorGreen : uBlueprintFillColor) : vColor;
    // Wider range than the old 0.3-0.6 (barely a 2x spread) so faces at
    // different angles to uLightDir read as clearly distinct shades instead
    // of nearly-uniform navy. Floor raised further (0.12 -> 0.3) so unlit
    // faces stay bright too, not just the lit ones.
    float shade = uBlueprint ? (0.3 + diff * 1.1) : brightness;
    vec3 color = base * shade;
    vec2 flowIntensity = flowPulseIntensity();
    color += uFlowColor * flowIntensity.x + uFlowCoreColor * flowIntensity.y;
    // Fill-pattern-flagged faces (see aFillPattern / materialFillPatternId)
    // get uHatchLineColor drawn on top of everything above in whichever
    // pattern their material selected, so it reads on top of blueprint
    // fill, shaded-mode lighting, and the flow glow alike.
    int fillPatternId = int(vFillPattern + 0.5);
    float fillMask = 0.0;
    if (fillPatternId == 1) fillMask = hatchLinesMask(vPosition, vNormal);
    else if (fillPatternId == 2) fillMask = dotsMask(vPosition, vNormal);
    else if (fillPatternId == 3) fillMask = plusMask(vPosition, vNormal);
    if (fillPatternId != 0) {
      color = mix(color, uHatchLineColor, fillMask);
    }
    gl_FragColor = vec4(color, uOpacity);
  }
`)),L.linkProgram(R),!L.getProgramParameter(R,L.LINK_STATUS))throw Error(L.getProgramInfoLog(R));let z=L.createProgram();if(L.attachShader(z,ce(L.VERTEX_SHADER,`
  attribute vec3 aLinePosition;
  attribute vec3 aLineColor;
  uniform mat4 uLineModelView;
  uniform mat4 uLineProjection;
  varying vec3 vLineColor;
  void main() {
    gl_Position = uLineProjection * uLineModelView * vec4(aLinePosition, 1.0);
    vLineColor = aLineColor;
  }
`)),L.attachShader(z,ce(L.FRAGMENT_SHADER,`
  precision mediump float;
  varying vec3 vLineColor;
  uniform float uLineAlpha;
  void main() {
    gl_FragColor = vec4(vLineColor, uLineAlpha);
  }
`)),L.linkProgram(z),!L.getProgramParameter(z,L.LINK_STATUS))throw Error(L.getProgramInfoLog(z));let le={dark:{bg:[4/255,28/255,44/255],fill:[4/255,28/255,44/255],line:[124/255,134/255,142/255]},light:{bg:[1,1,1],fill:[244/255,246/255,247/255],line:[4/255,28/255,44/255]}},ue=[68/255,214/255,44/255],de=[0,0,0],fe=[1,1,1],pe=[1,1,1],me=Math.cos(25*Math.PI/180);function he(e,t,n){let r=e.length/3,i=new Map,a=t.length/3;for(let o=0;o<a;o++){let a=t[o*3],s=t[o*3+1],c=t[o*3+2],l=e[a*3],u=e[a*3+1],d=e[a*3+2],f=e[s*3],p=e[s*3+1],m=e[s*3+2],h=e[c*3],g=e[c*3+1],_=e[c*3+2],v=f-l,y=p-u,b=m-d,x=h-l,S=g-u,C=_-d,w=y*C-b*S,T=b*x-v*C,E=v*S-y*x,D=Math.hypot(w,T,E)||1;w/=D,T/=D,E/=D;let O=!!n[o],k=[[a,s],[s,c],[c,a]];for(let[e,t]of k){let n=e<t?e*r+t:t*r+e,a=i.get(n);if(!a)i.set(n,{i0:e,i1:t,nx:w,ny:T,nz:E,minDot:1,count:1,isGreen:O});else{let e=a.nx*w+a.ny*T+a.nz*E;e<a.minDot&&(a.minDot=e),a.count++,O&&(a.isGreen=!0)}}}let o=[],s=[];for(let{i0:t,i1:n,count:r,minDot:a,isGreen:c}of i.values())(r===1||a<me)&&(o.push(e[t*3],e[t*3+1],e[t*3+2],e[n*3],e[n*3+1],e[n*3+2]),s.push(c));return{positions:new Float32Array(o),isGreen:s,colors:ge(s,le[N].line)}}function ge(e,t){let n=new Float32Array(e.length*6);for(let r=0;r<e.length;r++){let i=e[r]?de:t,a=r*6;n[a]=i[0],n[a+1]=i[1],n[a+2]=i[2],n[a+3]=i[0],n[a+4]=i[1],n[a+5]=i[2]}return n}function _e(){let e=le[N].line;Jn&&(L.bindBuffer(L.ARRAY_BUFFER,vn),L.bufferData(L.ARRAY_BUFFER,ge(Jn,e),L.STATIC_DRAW))}let ve=L.getAttribLocation(R,`aPosition`),ye=L.getAttribLocation(R,`aNormal`),be=L.getAttribLocation(R,`aColor`),xe=L.getAttribLocation(R,`aIsGreen`),Se=L.getAttribLocation(R,`aFlowCoord`),Ce=L.getAttribLocation(R,`aFlowPathLen`),we=L.getAttribLocation(R,`aFillPattern`),Te=L.getUniformLocation(R,`uModelView`),Ee=L.getUniformLocation(R,`uProjection`),De=L.getUniformLocation(R,`uLightDir`),Oe=L.getUniformLocation(R,`uLightIntensity`),ke=L.getUniformLocation(R,`uBlueprint`),Ae=L.getUniformLocation(R,`uOpacity`),je=L.getUniformLocation(R,`uBlueprintFillColor`),Me=L.getUniformLocation(R,`uBlueprintFillColorGreen`),Ne=L.getUniformLocation(R,`uFlowActive`),Pe=L.getUniformLocation(R,`uFlowWorldPos`),Fe=L.getUniformLocation(R,`uFlowReferenceLength`),Ie=L.getUniformLocation(R,`uFlowRange`),Le=L.getUniformLocation(R,`uFlowPad`),Re=L.getUniformLocation(R,`uFlowPulseDensity`),ze=L.getUniformLocation(R,`uFlowSigma`),Be=L.getUniformLocation(R,`uFlowColor`),Ve=L.getUniformLocation(R,`uFlowCoreColor`),He=L.getUniformLocation(R,`uFlowHeadWorldSigma`),Ue=L.getUniformLocation(R,`uFlowCoreWorldSigma`),We=L.getUniformLocation(R,`uFlowTailWorldSigma`),Ge=L.getUniformLocation(R,`uFlowTailFalloffExponent`),Ke=L.getUniformLocation(R,`uFlowTailVisible`),qe=L.getUniformLocation(R,`uHatchLineColor`),Je=L.getUniformLocation(R,`uLineFrequency`),Ye=L.getUniformLocation(R,`uDotFrequency`),Xe=L.getUniformLocation(R,`uDotRadius`),Ze=L.getUniformLocation(R,`uPlusFrequency`),Qe=L.getUniformLocation(R,`uPlusArmHalf`),$e=L.getUniformLocation(R,`uPlusThickness`),et=L.getAttribLocation(z,`aLinePosition`),tt=L.getAttribLocation(z,`aLineColor`),nt=L.getUniformLocation(z,`uLineModelView`),rt=L.getUniformLocation(z,`uLineProjection`),it=L.getUniformLocation(z,`uLineAlpha`);L.enable(L.DEPTH_TEST),L.clearColor(0,0,0,1);function at(e,t){let n=new Float32Array(16);for(let r=0;r<4;r++)for(let i=0;i<4;i++){let a=0;for(let n=0;n<4;n++)a+=e[n*4+i]*t[r*4+n];n[r*4+i]=a}return n}function ot(e,t,n,r,i,a){let o=1/(e-t),s=1/(n-r),c=1/(i-a);return new Float32Array([-2*o,0,0,0,0,-2*s,0,0,0,0,2*c,0,(e+t)*o,(r+n)*s,(a+i)*c,1])}function st(e){let t=Math.cos(e),n=Math.sin(e);return new Float32Array([1,0,0,0,0,t,n,0,0,-n,t,0,0,0,0,1])}function ct(e){let t=Math.cos(e),n=Math.sin(e);return new Float32Array([t,0,-n,0,0,1,0,0,n,0,t,0,0,0,0,1])}function lt(e,t,n){return new Float32Array([1,0,0,0,0,1,0,0,0,0,1,0,e,t,n,1])}function ut(e){return new Float32Array([e,0,0,0,0,e,0,0,0,0,e,0,0,0,0,1])}let dt=new Float32Array([1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1]),ft=5*Math.tan(Math.PI/8)/10,B=ft,V=ft,pt=ot(-B,B,-V,V,.1,100);function mt(e){e>=1?(B=ft,V=ft/e):(V=ft,B=ft*e),pt=ot(-B,B,-V,V,.1,100)}let ht=1/3*.1,H=ft*1.2,U=0,gt=0,W=0;function G(e){return Math.max(-300,Math.min(300,e))}function _t(){return[U/100*H,gt/100*H,W/100*H]}let vt=Math.PI/4,yt=Math.atan(1/Math.SQRT2);Math.PI/2;let bt=yt,xt=vt,St=!1,Ct=null,wt=!1,Tt=null,Et=!1,Dt=null,Ot=!1,kt=null,At=null;function jt(){At===null&&(At=requestAnimationFrame(()=>{At=null,Y()}))}function Mt(){At!==null&&(cancelAnimationFrame(At),At=null),Y()}let Nt=.1,Pt=0,Ft=0,It=0,Lt=0,Rt=null,K=e=>1-(1-e)**3,zt=null,q=null,Bt=yt,Vt=vt,Ht=100,Ut=0,Wt=180,Gt=0,Kt=180,qt=K,Jt=K,Yt=!0;function Xt(e,t,n=180,r=!0,i=K,a=0,o=n,s=K,c=0){let l=w;q={rotX:bt,rotY:xt,parX:It,parY:Lt,parTargetX:Pt,parTargetY:Ft,sizePercent:l*(1+a)},Bt=e,Vt=t,Ht=l,Ut=a,Kt=o,Jt=s,Yt=r,Wt=n,qt=i,Gt=c,zt=performance.now()}function Zt(){Qt=!1,Xt(yt,vt)}let Qt=!1,$t=K;function en(){s.style.cursor=`default`}en();let tn=null;function nn(){tn===null&&(tn=requestAnimationFrame(()=>{tn=null,p(`cubeSize`,w),Y()}))}s.addEventListener(`pointerdown`,e=>{if(e.pointerType!==`touch`&&!Er&&wr){if(e.button!==2)return;St=!0,Ct={x:e.clientX,y:e.clientY},s.style.cursor=`grabbing`;return}},{signal:a.signal}),window.addEventListener(`pointermove`,e=>{if(Ot){let t=e.clientX-kt.x,n=e.clientY-kt.y;kt={x:e.clientX,y:e.clientY};let r=B*2/window.innerWidth*(100/H),i=V*2/window.innerHeight*(100/H);U=G(U+t*r),W=G(W+n*i),jt();return}if(Et){let t=e.clientY-Dt.y;Dt={x:e.clientX,y:e.clientY};let n=V*2/window.innerHeight*(100/H);gt=G(gt-t*n),jt();return}if(wt){let t=e.clientX-Tt.x,n=e.clientY-Tt.y;Tt={x:e.clientX,y:e.clientY};let r=B*2/window.innerWidth*(100/H),i=V*2/window.innerHeight*(100/H);U=G(U+t*r),W=G(W+n*i),jt();return}if(St){xt+=(e.clientX-Ct.x)*.01,bt+=(e.clientY-Ct.y)*.01,Ct={x:e.clientX,y:e.clientY};return}},{signal:a.signal});function rn(){if(Rt!==null){let e=Math.min(1,(performance.now()-Rt)/2500),t=K(e);It=0+(Pt-0)*t,Lt=0+(Ft-0)*t,e>=1&&(Rt=null)}else It+=(Pt-It)*Nt,Lt+=(Ft-Lt)*Nt}window.addEventListener(`pointerenter`,e=>{},{signal:a.signal}),window.addEventListener(`pointerup`,()=>{St=!1,wt&&(wt=!1,Mt()),Et&&(Et=!1,Mt()),Ot&&(Ot=!1,Mt()),en()},{signal:a.signal});let an=-Math.PI/2;function on(e){let t={},n=null;for(let r of e.split(`
`)){let e=r.trim();if(e.startsWith(`newmtl `))n=e.slice(7).trim(),t[n]=[1,1,1];else if(e.startsWith(`Kd `)&&n){let r=e.split(/\s+/);t[n]=[parseFloat(r[1]),parseFloat(r[2]),parseFloat(r[3])]}}return t}function sn(e,t,n=1){let r=[],i=[],a=[],o=[],s=[],c=[],l=[],u=[],d=[],f=[],p=[],m=[],h=[],g=[1,1,1],_=!1,v=0,y=!1,b=null,x=!1,S=new Map,C=[];function w(e,t,n){let r=b||`Object 1`,i=S.get(r);i||(i={minX:1/0,minY:1/0,minZ:1/0,maxX:-1/0,maxY:-1/0,maxZ:-1/0},S.set(r,i),C.push(r)),e<i.minX&&(i.minX=e),e>i.maxX&&(i.maxX=e),t<i.minY&&(i.minY=t),t>i.maxY&&(i.maxY=t),n<i.minZ&&(i.minZ=n),n>i.maxZ&&(i.maxZ=n)}let T=e.split(`
`);for(let e of T){let n=e.trim();if(n[0]===`v`&&n[1]===` `){let e=n.split(/\s+/);r.push([parseFloat(e[1]),parseFloat(e[2]),parseFloat(e[3])])}else if(n.startsWith(`vn `)){let e=n.split(/\s+/);i.push([parseFloat(e[1]),parseFloat(e[2]),parseFloat(e[3])])}else if(n[0]===`o`&&n[1]===` `)x=!0,b=n.slice(2).trim()||b;else if(n[0]===`g`&&n[1]===` `&&!x)b=n.slice(2).trim()||b;else if(n.startsWith(`usemtl `)){let e=n.slice(7).trim();g=t[e]||[1,1,1],_=li(g[0]*255,g[1]*255,g[2]*255),v=ui(e),y=di(e)}else if(n[0]===`f`&&n[1]===` `){let e=n.split(/\s+/).slice(1).map(e=>{let[t,,n]=e.split(`/`),a=parseInt(t,10),o=a>0?a-1:r.length+a,s=null;if(n){let e=parseInt(n,10);s=e>0?e-1:i.length+e}return{vIdx:o,vnIdx:s}});for(let t=1;t<e.length-1;t++){let n=[e[0],e[t],e[t+1]],x=n.map(e=>r[e.vIdx]),S=n.map(e=>e.vnIdx===null?null:i[e.vnIdx]);if(S.some(e=>!e)){let e=x[1][0]-x[0][0],t=x[1][1]-x[0][1],n=x[1][2]-x[0][2],r=x[2][0]-x[0][0],i=x[2][1]-x[0][1],a=x[2][2]-x[0][2],o=t*a-n*i,s=n*r-e*a,c=e*i-t*r,l=Math.hypot(o,s,c)||1;o/=l,s/=l,c/=l,S=[[o,s,c],[o,s,c],[o,s,c]]}y?h.push(!1):f.push(_);for(let e=0;e<3;e++)y?(p.push(x[e][0],x[e][1],x[e][2]),m.push(n[e].vIdx)):(a.push(x[e][0],x[e][1],x[e][2]),o.push(S[e][0],S[e][1],S[e][2]),s.push(g[0],g[1],g[2]),c.push(+!!_),l.push(b||`Object 1`),u.push(v),d.push(n[e].vIdx)),w(x[e][0],x[e][1],x[e][2])}}}if(a.length===0)return null;let E=an;if(E!==0){let e=Math.cos(E),t=Math.sin(E);for(let n=0;n<a.length;n+=3){let r=a[n],i=a[n+2];a[n]=r*e+i*t,a[n+2]=-r*t+i*e;let s=o[n],c=o[n+2];o[n]=s*e+c*t,o[n+2]=-s*t+c*e}for(let n=0;n<p.length;n+=3){let r=p[n],i=p[n+2];p[n]=r*e+i*t,p[n+2]=-r*t+i*e}}let D=1/0,O=1/0,k=1/0,A=-1/0,j=-1/0,M=-1/0;for(let e=0;e<a.length;e+=3){let t=a[e],n=a[e+1],r=a[e+2];t<D&&(D=t),t>A&&(A=t),n<O&&(O=n),n>j&&(j=n),r<k&&(k=r),r>M&&(M=r)}let N=(D+A)/2,P=O,F=(k+M)/2,I=2/(Math.max(A-D,j-O,M-k)||1)*10*n;for(let e=0;e<a.length;e+=3)a[e]=(a[e]-N)*I,a[e+1]=(a[e+1]-P)*I,a[e+2]=(a[e+2]-F)*I;for(let e=0;e<p.length;e+=3)p[e]=(p[e]-N)*I,p[e+1]=(p[e+1]-P)*I,p[e+2]=(p[e+2]-F)*I;let ee=C.map(e=>{let t=S.get(e),n=(t.minX+t.maxX)/2,r=(t.minY+t.maxY)/2,i=(t.minZ+t.maxZ)/2;if(E!==0){let e=Math.cos(E),t=Math.sin(E),r=n*e+i*t,a=-n*t+i*e;n=r,i=a}let a=Math.hypot(t.maxX-t.minX,t.maxY-t.minY,t.maxZ-t.minZ)*I,o=1/0,s=-1/0,c=1/0,l=-1/0;for(let e of[t.minX,t.maxX])for(let n of[t.minZ,t.maxZ]){let t=e,r=n;if(E!==0){let i=Math.cos(E),a=Math.sin(E);t=e*i+n*a,r=-e*a+n*i}t<o&&(o=t),t>s&&(s=t),r<c&&(c=r),r>l&&(l=r)}let u={minX:(o-N)*I,maxX:(s-N)*I,minY:(t.minY-P)*I,maxY:(t.maxY-P)*I,minZ:(c-F)*I,maxZ:(l-F)*I};return{name:e,center:[(n-N)*I,(r-P)*I,(i-F)*I],size:a,bounds:u}}),te=new Map(C.map((e,t)=>[e,t])),ne=l.map(e=>te.get(e)),re=new Float32Array(r.length*3);for(let e=0;e<r.length;e++){let[t,n,i]=r[e];if(E!==0){let e=Math.cos(E),n=Math.sin(E),r=t*e+i*n,a=-t*n+i*e;t=r,i=a}re[e*3]=(t-N)*I,re[e*3+1]=(n-P)*I,re[e*3+2]=(i-F)*I}let ie=he(re,new Uint32Array(d),f),ae=he(re,new Uint32Array(m),h);return{positions:new Float32Array(a),normals:new Float32Array(o),colors:new Float32Array(s),isGreen:new Float32Array(c),objectIndex:new Float32Array(ne),fillPattern:new Float32Array(u),targetPositions:new Float32Array(p),targetLinePositions:ae.positions,linePositions:ie.positions,lineColors:ie.colors,lineIsGreen:ie.isGreen,hasMaterials:Object.keys(t).length>0,objects:ee}}let cn=L.createBuffer(),ln=L.createBuffer(),un=L.createBuffer(),dn=L.createBuffer(),fn=L.createBuffer(),pn=L.createBuffer(),mn=L.createBuffer(),hn=L.createBuffer(),gn=L.createBuffer(),_n=L.createBuffer(),vn=L.createBuffer();L.createBuffer(),L.createBuffer();let yn=0,bn=0,xn=!1,Sn=``,Cn=[],wn=[],Tn=Array(7).fill(null),En=null,Dn=[0,0,0],On=null;function kn(){Dn=[0,0,0],J=1,An=[0,0,0],jn=0,Mn=null,Nn=!0}let J=1,An=[0,0,0],jn=0,Mn=null,Nn=!0,Pn=.05,Fn=.01;function In(){return{spaceHeld:!1,photoMode:!1,photoExport2x:!0,photoUniformLineWidth:!0,videoMode:!1,videoRecording:!1,videoExportDurationMs:si,pngSequenceExporting:!1,pngSequenceProgress:0,rotationDisabled:!0,modelOffsetX:U,modelOffsetY:gt,customModelReady:xn,cubeSize:w,cubeModelStatus:Sn,batteryStackAvailable:!!X,batteryStackEnabled:Xn,batteryStackCount:Zn,batteryStackAnimation:er,batteryModelLoading:tr,batteryModel:$n,customModelObjectNames:X?.activeNames??wn.map(e=>e.name),cameraTargetSlots:Tn,cameraTargetActiveIndex:En,showCameraTargetBoxes:!1,showTargetMaterials:!1,hasDefaultCameraView:!1,editingDefaultView:!1,modelFlowArrowCount:Dr.length,selectedFlowArrowIndex:Or,modelFlowDrawMode:wr,modelFlowSelectMode:Er,showModelFlowArrow:kr,selectedFlowArrowObjects:(()=>{let e=Or===null?null:Dr[Or];return!e||e.touchedObjectIndices.length<=1?[]:e.touchedObjectIndices.map(t=>({index:t,name:wn[t]?.name??`Object ${t+1}`,enabled:e.enabledObjectIndices.includes(t)}))})(),selectedFlowArrowReversed:!!(Or!==null&&Dr[Or]?.reversed)}}function Ln(e){let t=Tn[e];return Rn(t?wn.find(e=>e.name===t):null)}function Rn(e){let t=e?e.center:[0,0,0],n=1;if(e&&e.bounds){let{minX:t,maxX:r,minY:i,maxY:a,minZ:o,maxZ:s}=e.bounds,[c,l,u]=e.center,d=1/0,f=-1/0;for(let e of[t,r])for(let t of[i,a])for(let n of[o,s]){let r=Gr(Kr([e-c,t-l,n-u],vt),yt);r[1]<d&&(d=r[1]),r[1]>f&&(f=r[1])}let p=f-d;if(p>1e-6){let e=Tr===null?T:Tr/100;n=Math.max(.01,Math.min(50,.5*2*V/(p*ht*e)))}}return{center:t,zoomGoal:n}}let zn=!1,Bn=[0,0,0],Vn=[0,0,0],Hn=K,Un=K;function Wn(){On!==null&&(clearTimeout(On),On=null),zn=!1,En=null,Y()}function Y(){let e=In();Cn.forEach(t=>t(e))}let Gn=null,Kn=null,qn=null,Jn=null,Yn=null,X=null,Xn=!1,Zn=u,Qn=[`EP5`,`EP12`],$n=r.model,er=!0,tr=!1,nr=[],rr=!1,ir=[],ar=[],or=[],Z=0,Q=0,sr=null;function cr(){let e=X?.centerOffset??0,t=performance.now(),n=sr===null?0:Math.min(Pn,(t-sr)/1e3);sr=t,!(Z===e&&Q===0)&&([Z,Q]=qr(Z,Q,e,n,120,25.4),Math.abs(Z-e)<1e-4&&Math.abs(Q)<.001&&(Z=e,Q=0))}function lr(){return r.reducedMotion}function ur(e=Zn,t=Xn,n=er,r=!1){if(!X||!Number.isInteger(e)||e<l||e>u)return;Zn=e,Xn=!!t,er=!!n;let i=er&&!lr();X.configure(e,Xn,i,performance.now(),r),i||(Z=X.centerOffset,Q=0),$r(),dr(),Y()}function dr(){let e=X?.update(performance.now());if(!e)return;let t=(e,t,n=!1)=>{L.bindBuffer(L.ARRAY_BUFFER,e),n?L.bufferSubData(L.ARRAY_BUFFER,0,t):L.bufferData(L.ARRAY_BUFFER,t,L.DYNAMIC_DRAW)};if(t(cn,e.positions,!e.membershipChanged),t(_n,e.linePositions,!e.membershipChanged),e.membershipChanged&&(t(ln,e.normals),t(un,e.colors),t(dn,e.isGreen),t(fn,e.fillPattern),Jn=e.lineIsGreen,_e()),yn=e.positions.length/3,bn=e.linePositions.length/3,Gn=e.positions,qn=e.objectIndex,Kn=e.isGreen,e.linePositions,wn=e.objects,ir=e.vertexRanges,ar=e.lineRanges,or=e.fades,e.membershipChanged){let t=[];nr=[];let n=0;for(let r=0;r<e.isGreen.length;r+=3){if(!e.isGreen[r])continue;t.push(e.objectIndex[r]);let i=r*3,a=nr.at(-1);a&&a.start+a.length===i?a.length+=9:nr.push({start:i,length:9,offset:n}),n+=9}new Int32Array(t),rr=n===e.positions.length,rr||(Yn=new Float32Array(n))}if(rr)Yn=e.positions;else for(let t of nr)Yn.set(e.positions.subarray(t.start,t.start+t.length),t.offset);e.membershipChanged&&Qr()}function fr(e,t,n,r){let i=new Map(or.map(e=>[e.index,e.opacity])),a=t=>L.drawArrays(e,t.start/3,(t.end-t.start)/3);for(let e of t)i.has(e.index)||a(e);L.enable(L.BLEND),L.blendFuncSeparate(L.SRC_ALPHA,L.ONE_MINUS_SRC_ALPHA,L.ONE,L.ONE_MINUS_SRC_ALPHA);for(let[e,o]of i){if(o<=0)continue;let i=t.filter(t=>t.index===e);r&&(L.colorMask(!1,!1,!1,!1),i.forEach(a),L.colorMask(!0,!0,!0,!0),L.depthFunc(L.LEQUAL)),n(o),i.forEach(a),r&&L.depthFunc(L.LESS)}n(1),L.disable(L.BLEND)}let pr=!1,mr=!1;function hr(e){if(!er||lr())return;let t=s.clientHeight/(2*V),n=ht*T*J,r=c?Math.hypot(Math.sin(xt),Math.sin(bt)*Math.cos(xt)):Math.cos(bt),i=50/(t*n*Math.max(.2,r));X.spreadApart(i,e),dr()}function gr(){pr||!mr||!X||!Xn||(pr=!0,X.settle(performance.now()),dr())}function _r(e){if(!c||!X?.focus)return;let t=X.focusedModel;X.focus(e),$n=X.focusedModel,$n!==t&&Xn&&(hr($n),X.settle(performance.now(),void 0,300),dr()),Y()}async function vr(){let e=c?Qn.map(e=>`${e}-battery-stack`):[`NGEN_assets`],n=e.join(` + `);if(!tr){tr=!0,Y();try{let[i,o]=await Promise.all([`obj`,`mtl`].map(async n=>{let i=await Promise.all(e.map(async e=>{let t=`${r.modelBaseUrl}${e}.${n}`,i=await fetch(t,{signal:a.signal});if(!i.ok)throw Error(`Battery model file ${t} is unavailable.`);return i.text()}));return n===`obj`?t(i):i.join(`
`)}));if(a.signal.aborted)return;let s=sn(i,on(o));if(!s)throw Error(`Battery model has no faces.`);if(yr(s,`${n}.obj`,`${n}.mtl`),_r($n),$r(),!X)throw Error(`${n} is not the expected battery model.`);ur(r.count,!0),Z=X?.centerOffset??0,Q=0,pr=!1,hr(),gr(),r.onReady()}catch(e){if(a.signal.aborted)return;r.onError(e),Sn=`Couldn't load ${n}.obj`}finally{tr=!1,Y()}}}function yr(t,r,i,a=[]){if(!t){xn=!1,Sn=`Couldn't find any faces in ${r}`,Y();return}X=c?n(t):e(t),or=[],Z=0,Q=0,Xn=!1,Zn=u,L.bindBuffer(L.ARRAY_BUFFER,cn),L.bufferData(L.ARRAY_BUFFER,t.positions,L.STATIC_DRAW),L.bindBuffer(L.ARRAY_BUFFER,ln),L.bufferData(L.ARRAY_BUFFER,t.normals,L.STATIC_DRAW),L.bindBuffer(L.ARRAY_BUFFER,un),L.bufferData(L.ARRAY_BUFFER,t.colors,L.STATIC_DRAW),L.bindBuffer(L.ARRAY_BUFFER,dn),L.bufferData(L.ARRAY_BUFFER,t.isGreen,L.STATIC_DRAW),L.bindBuffer(L.ARRAY_BUFFER,fn),L.bufferData(L.ARRAY_BUFFER,t.fillPattern,L.STATIC_DRAW),yn=t.positions.length/3,L.bindBuffer(L.ARRAY_BUFFER,pn),L.bufferData(L.ARRAY_BUFFER,t.targetPositions,L.STATIC_DRAW),t.targetPositions.length/3,L.bindBuffer(L.ARRAY_BUFFER,mn),L.bufferData(L.ARRAY_BUFFER,t.targetLinePositions,L.STATIC_DRAW),t.targetLinePositions.length/3,L.bindBuffer(L.ARRAY_BUFFER,_n),L.bufferData(L.ARRAY_BUFFER,t.linePositions,L.STATIC_DRAW),L.bindBuffer(L.ARRAY_BUFFER,vn),L.bufferData(L.ARRAY_BUFFER,t.lineColors,L.STATIC_DRAW),bn=t.linePositions.length/3,Gn=t.positions,Kn=t.isGreen,qn=t.objectIndex,t.linePositions,Jn=t.lineIsGreen,wn=t.objects,Tn=Array.from({length:7},(e,t)=>a[t]??null);let o=/^target_(\d+)$/i;for(let e of t.objects){let t=o.exec(e.name);if(!t)continue;let n=Number(t[1])-1;n>=0&&n<7&&(Tn[n]=e.name)}En=null,Dn=[0,0,0],J=1,An=[0,0,0],jn=0,Mn=null,Nn=!0;let s=[],l=[];for(let e=0;e<t.isGreen.length;e+=3)if(t.isGreen[e]){let n=e*3;for(let e=0;e<9;e++)s.push(t.positions[n+e]);l.push(t.objectIndex[e])}Yn=new Float32Array(s),xn=!0,D(100);let d=yn/3;if(Sn=t.hasMaterials?`${r} (${d} tris, colors from ${i})`:`${r} (${d} tris, no materials found)`,br=null,X){Wn(),kn();let e={minX:Math.min(...t.objects.map(e=>e.bounds.minX)),maxX:Math.max(...t.objects.map(e=>e.bounds.maxX)),minY:Math.min(...t.objects.map(e=>e.bounds.minY)),maxY:Math.max(...t.objects.map(e=>e.bounds.maxY)),minZ:Math.min(...t.objects.map(e=>e.bounds.minZ)),maxZ:Math.max(...t.objects.map(e=>e.bounds.maxZ))};br={center:[(e.minX+e.maxX)/2,(e.minY+e.maxY)/2,(e.minZ+e.maxZ)/2],bounds:e},xr(),Zt()}Y()}let br=null;function xr(){if(!X||!br)return;E(100),D(Math.min(...(X.frames??[br]).map(e=>Rn(e).zoomGoal))*100);let e=ht*T,{center:t}=br;U=-t[0]*e/H*100,gt=-t[1]*e/H*100,W=-t[2]*e/H*100}let Sr=[.2,.45,.95],Cr=[1,0,0],wr=!1,Tr=null,Er=!1,Dr=[],Or=null,kr=!1,Ar=L.createBuffer();L.createBuffer();function jr(e,t,n,r,i,a){let o=t/2,s=n/2,c=r/o,l=r/s,[u,d,f]=e,p=[];for(let e=0;e<20;e++){let t=e/20*Math.PI*2,n=(e+1)/20*Math.PI*2;p.push(u,d,f,...i,u+Math.cos(t)*c,d+Math.sin(t)*l,f,...a,u+Math.cos(n)*c,d+Math.sin(n)*l,f,...a)}return p}function Mr(e,t,n,r,i,a,o){let s=[];for(let c of e){let e=t[0]*c[0]+t[4]*c[1]+t[8]*c[2]+t[12],l=t[1]*c[0]+t[5]*c[1]+t[9]*c[2]+t[13],u=t[2]*c[0]+t[6]*c[1]+t[10]*c[2]+t[14];s.push(...jr([e,l,u],n,r,i,a,o))}return new Float32Array(s)}function Nr(e,t,n,r,i){if(e.length===0)return;let a=Mr(e,t,s.width,s.height,n,r,i);L.bindBuffer(L.ARRAY_BUFFER,Hr),L.bufferData(L.ARRAY_BUFFER,a,L.DYNAMIC_DRAW),L.vertexAttribPointer(et,3,L.FLOAT,!1,24,0),L.vertexAttribPointer(tt,3,L.FLOAT,!1,24,12),L.drawArrays(L.TRIANGLES,0,a.length/6)}let Pr=[1,1,1],Fr=[.55,.55,.55],Ir=[1,.92,.3],Lr=[.75,.6,.05],Rr=[1,.55,.1],zr=[.65,.3,.02],Br=[.3,.55,1],Vr=[.1,.25,.7],Hr=L.createBuffer();L.createBuffer(),L.createBuffer(),L.createBuffer();function Ur(e,t,n,r,i,a){let o=(n[0]-t[0])*r,s=(n[1]-t[1])*i,c=Math.hypot(o,s)||1;o/=c,s/=c;let l=-s*a,u=o*a,d=-o*a,f=-s*a;for(let n=0;n<10;n++){let a=Math.PI*n/10,o=Math.PI*(n+1)/10,s=l*Math.cos(a)+d*Math.sin(a),c=u*Math.cos(a)+f*Math.sin(a),p=l*Math.cos(o)+d*Math.sin(o),m=u*Math.cos(o)+f*Math.sin(o);e.push(t[0],t[1],t[2],t[0]+s/r,t[1]+c/i,t[2],t[0]+p/r,t[1]+m/i,t[2])}}function Wr(e,t,n,r,i){let a=n/2,o=r/2,s=i*4,c=i*2.2,l=[];for(let n of e){let e=n.map(e=>[t[0]*e[0]+t[4]*e[1]+t[8]*e[2]+t[12],t[1]*e[0]+t[5]*e[1]+t[9]*e[2]+t[13],t[2]*e[0]+t[6]*e[1]+t[10]*e[2]+t[14]]);e.length>=2&&Ur(l,e[0],e[1],a,o,i);for(let t=0;t<e.length-1;t++){let n=e[t],r=e[t+1],u=(r[0]-n[0])*a,d=(r[1]-n[1])*o,f=Math.hypot(u,d)||1;u/=f,d/=f;let p=-d*i/a,m=u*i/o,h=n[0]-p,g=n[1]-m,_=n[0]+p,v=n[1]+m,y=r[0]-p,b=r[1]-m,x=r[0]+p,S=r[1]+m;if(l.push(h,g,n[2],y,b,r[2],_,v,n[2],_,v,n[2],y,b,r[2],x,S,r[2]),t===e.length-2){let e=u*s/a,t=d*s/o,n=r[0]-e,i=r[1]-t,f=-d*c/a,p=u*c/o;l.push(r[0],r[1],r[2],n-f,i-p,r[2],n+f,i+p,r[2])}}}return new Float32Array(l)}function Gr(e,t){let n=Math.cos(t),r=Math.sin(t);return[e[0],e[1]*n-e[2]*r,e[1]*r+e[2]*n]}function Kr(e,t){let n=Math.cos(t),r=Math.sin(t);return[e[0]*n+e[2]*r,e[1],-e[0]*r+e[2]*n]}function qr(e,t,n,r,i=15,a=9){if(r<=0)return[e,t];let o=Math.sqrt(i),s=a/(2*o),c=e-n,l=t,u=o*Math.sqrt(s*s-1),d=-s*o+u,f=-s*o-u,p=(l-c*f)/(d-f),m=c-p,h=Math.exp(d*r),g=Math.exp(f*r),_=p*h+m*g,v=p*d*h+m*f*g;return[_+n,v]}function Jr(e,t,n,r){return Gr(Kr([e[0]*r,e[1]*r,e[2]*r],n),t)}function Yr(e,t,n){let r=Jr(Dn,e,t,n);return[-r[0],-r[1]+0+0]}function Xr(){if(En!==null||!Nn)return[0,0,0];let[e,t,n]=_t(),r=Z*ht*T*J;return c?[e,t,n-r]:[e,t-r,n]}function Zr(e,t){let{points:n,cumLen:r}=e,i=1/0,a=0;for(let e=0;e<n.length-1;e++){let o=n[e],s=n[e+1],c=s[0]-o[0],l=s[1]-o[1],u=s[2]-o[2],d=c*c+l*l+u*u||1,f=t[0]-o[0],p=t[1]-o[1],m=t[2]-o[2],h=(f*c+p*l+m*u)/d;h=Math.max(0,Math.min(1,h));let g=o[0]+c*h,_=o[1]+l*h,v=o[2]+u*h,y=t[0]-g,b=t[1]-_,x=t[2]-v,S=y*y+b*b+x*x;S<i&&(i=S,a=r[e]+Math.sqrt(d)*h)}return{arcLen:a,distSq:i}}function Qr(){if(!xn||!Gn)return;let e=Gn.length/3,t=new Float32Array(e).fill(-1),n=new Float32Array(e).fill(1);if(Dr.length>0)for(let r=0;r<e;r++){if(!Kn[r])continue;let e=qn[r],i=[Gn[r*3],Gn[r*3+1],Gn[r*3+2]],a=-1,o=1/0,s=1;for(let t of Dr){if(t.enabledObjectIndices&&!t.enabledObjectIndices.includes(e))continue;let{arcLen:n,distSq:r}=Zr(t,i);if(r<o){o=r;let e=t.masterTotalLen||t.totalLen;a=e>0?((t.sourceOffset||0)+n)/e:0,s=e||1}}t[r]=a,n[r]=s}L.bindBuffer(L.ARRAY_BUFFER,hn),L.bufferData(L.ARRAY_BUFFER,t,L.STATIC_DRAW),L.bindBuffer(L.ARRAY_BUFFER,gn),L.bufferData(L.ARRAY_BUFFER,n,L.STATIC_DRAW)}function $r(){Dr=[],Or=null,Qr(),Y()}let ei=Math.max(1,window.devicePixelRatio||1);2*ei,11*ei;function ti(){dr(),L.viewport(0,0,s.width,s.height);let e=+!oi;if(se){let t=le[N].bg;L.clearColor(t[0],t[1],t[2],e)}else L.clearColor(0,0,0,e);if(L.clear(L.COLOR_BUFFER_BIT|L.DEPTH_BUFFER_BIT),zt!==null){let e=performance.now(),t=Math.min(1,Math.max(0,e-zt-Gt)/Wt),n=qt(t);bt=q.rotX+(Bt-q.rotX)*n,xt=q.rotY+(Vt-q.rotY)*n;let r=Ut===0?1:Math.min(1,(e-zt)/Kt);if(Ut!==0){let e=Jt(r);E(q.sizePercent+(Ht-q.sizePercent)*e),nn()}Yt?(Pt=q.parTargetX*(1-n),Ft=q.parTargetY*(1-n),It=q.parX*(1-n),Lt=q.parY*(1-n)):rn(),t>=1&&r>=1&&(zt=null,q=null)}else rn();if(Qt){let e=Math.min(1,(performance.now()-null)/0);xt=0+0*$t(e),e>=1&&(Qt=!1)}let t=bt+It,n=xt+Lt,r=En===null?null:Tn[En];if(zn){let e=performance.now(),t=Math.min(1,(e-null)/180),n=Hn(t);Dn=[0,1,2].map(e=>Bn[e]+(Vn[e]-Bn[e])*n);let r=Math.min(1,Math.max(0,e-null-0)/180);J=1+0*Un(r),t>=1&&r>=1&&(zn=!1,An=[0,0,0],jn=0,Mn=null),Nn=!1}else{let e=r?Ln(En):{center:[0,0,0],zoomGoal:1},t=e.center,n=e.zoomGoal,i=performance.now(),a=Mn===null?0:Math.min(Pn,(i-Mn)/1e3);Mn=i;let o=[0,0,0];for(let e=0;e<3;e++)[o[e],An[e]]=qr(Dn[e],An[e],t[e],a);Dn=o,[J,jn]=qr(J,jn,n,a,4,4.65),Nn=!r&&Math.hypot(...Dn)<Fn&&Math.hypot(...An)<Fn&&Math.abs(J-1)<Fn&&Math.abs(jn)<Fn}let i=ht*T*J,[a,o]=Yr(t,n,i);cr();let[c,l,u]=Xr(),d=lt(a,o,-5);d=at(d,st(t)),d=at(d,ct(n)),d=at(d,lt(c,l,u)),d=at(d,ut(i)),L.useProgram(R),L.uniformMatrix4fv(Te,!1,d),L.uniformMatrix4fv(Ee,!1,pt);let f=re*Math.PI/180,p=ie*Math.PI/180;L.uniform3f(De,Math.cos(p)*Math.cos(f),Math.sin(p),Math.cos(p)*Math.sin(f)),L.uniform1f(Oe,ae/100),L.uniform1i(ke,+!!se),L.uniform1f(Ae,1);let m=le[N].fill;L.uniform3f(je,m[0],m[1],m[2]),L.uniform3f(Me,ue[0],ue[1],ue[2]);let h=le[N].line;L.uniform3f(qe,h[0],h[1],h[2]),L.uniform1f(Je,O),L.uniform1f(Ye,k),L.uniform1f(Xe,A/100),L.uniform1f(Ze,j);let g=M/100;L.uniform1f(Qe,g),L.uniform1f($e,g*.12),L.bindBuffer(L.ARRAY_BUFFER,cn),L.enableVertexAttribArray(ve),L.vertexAttribPointer(ve,3,L.FLOAT,!1,0,0),L.bindBuffer(L.ARRAY_BUFFER,ln),L.enableVertexAttribArray(ye),L.vertexAttribPointer(ye,3,L.FLOAT,!1,0,0),L.bindBuffer(L.ARRAY_BUFFER,un),L.enableVertexAttribArray(be),L.vertexAttribPointer(be,3,L.FLOAT,!1,0,0),L.bindBuffer(L.ARRAY_BUFFER,dn),L.enableVertexAttribArray(xe),L.vertexAttribPointer(xe,1,L.FLOAT,!1,0,0),L.bindBuffer(L.ARRAY_BUFFER,fn),L.enableVertexAttribArray(we),L.vertexAttribPointer(we,1,L.FLOAT,!1,0,0),L.bindBuffer(L.ARRAY_BUFFER,hn),L.enableVertexAttribArray(Se),L.vertexAttribPointer(Se,1,L.FLOAT,!1,0,0),L.bindBuffer(L.ARRAY_BUFFER,gn),L.enableVertexAttribArray(Ce),L.vertexAttribPointer(Ce,1,L.FLOAT,!1,0,0);let _=se&&xn&&Dr.length>0,w=.02,D=0,P=0,F=0,I=0;if(_){w=Math.max(5e-4,.15*v*4),P=w*13,D=1+2*P;let e=3/(100/y*3e3);F=performance.now()*e,I=C/3}if(L.uniform1i(Ne,+!!_),_&&(L.uniform1f(Pe,F),L.uniform1f(Fe,3),L.uniform1f(Ie,D),L.uniform1f(Le,P),L.uniform1f(Re,I),L.uniform1f(ze,w),L.uniform3f(Be,fe[0],fe[1],fe[2]),L.uniform3f(Ve,pe[0],pe[1],pe[2]),L.uniform1f(He,w*.12*3),L.uniform1f(Ue,b/100*w*3),L.uniform1f(We,x/100*w*3),L.uniform1f(Ge,S),L.uniform1i(Ke,1)),se&&(L.enable(L.POLYGON_OFFSET_FILL),L.polygonOffset(1,1)),or.length>0?fr(L.TRIANGLES,ir,e=>L.uniform1f(Ae,e),!0):L.drawArrays(L.TRIANGLES,0,yn),se){L.disable(L.POLYGON_OFFSET_FILL),L.useProgram(z),L.uniform1f(it,1);let e=at(pt,d);L.uniformMatrix4fv(nt,!1,d),L.uniformMatrix4fv(rt,!1,pt),L.bindBuffer(L.ARRAY_BUFFER,_n),L.enableVertexAttribArray(et),L.vertexAttribPointer(et,3,L.FLOAT,!1,0,0),L.bindBuffer(L.ARRAY_BUFFER,vn),L.enableVertexAttribArray(tt),L.vertexAttribPointer(tt,3,L.FLOAT,!1,0,0),or.length>0?fr(L.LINES,ar,e=>L.uniform1f(it,e),!1):L.drawArrays(L.LINES,0,bn);let t=[],n=[],r=[];if(t.length>0||r.length>0){if(L.uniformMatrix4fv(nt,!1,dt),L.uniformMatrix4fv(rt,!1,dt),L.enableVertexAttribArray(et),L.disableVertexAttribArray(tt),L.enable(L.BLEND),L.blendFunc(L.SRC_ALPHA,L.ONE_MINUS_SRC_ALPHA),L.uniform1f(it,.75),t.length>0){let n=Wr(t,e,s.width,s.height,3);L.bindBuffer(L.ARRAY_BUFFER,Ar),L.bufferData(L.ARRAY_BUFFER,n,L.DYNAMIC_DRAW),L.vertexAttribPointer(et,3,L.FLOAT,!1,0,0),L.vertexAttrib3f(tt,Sr[0],Sr[1],Sr[2]),L.drawArrays(L.TRIANGLES,0,n.length/3)}if(r.length>0){let t=Wr(r,e,s.width,s.height,3);L.bindBuffer(L.ARRAY_BUFFER,Ar),L.bufferData(L.ARRAY_BUFFER,t,L.DYNAMIC_DRAW),L.vertexAttribPointer(et,3,L.FLOAT,!1,0,0),L.vertexAttrib3f(tt,Cr[0],Cr[1],Cr[2]),L.drawArrays(L.TRIANGLES,0,t.length/3)}L.disable(L.BLEND),L.uniform1f(it,1)}if(t.length>0){L.uniformMatrix4fv(nt,!1,dt),L.uniformMatrix4fv(rt,!1,dt),L.enableVertexAttribArray(et),L.enableVertexAttribArray(tt);let r=t;if(r.length>0){let t=new Set(n),i=new Set(r.map(e=>e[e.length-1])),a=new Map;for(let e of r)for(let n of e)t.has(n)||a.set(n,(a.get(n)||0)+1);let o=[],s=[],c=[];for(let[e,t]of a)t>=2?s.push(e):i.has(e)?c.push(e):o.push(e);Nr(o,e,12,Pr,Fr),Nr(s,e,16.200000000000003,Ir,Lr),Nr(c,e,16.200000000000003,Br,Vr),Nr(n,e,16.200000000000003,Rr,zr)}}}}let ni=.5,$=1,ri=0,ii=0;function ai(){s.width=Math.max(1,Math.round(ri*$)),s.height=Math.max(1,Math.round(ii*$))}let oi=!1;f(`photoLineWidthHalfPx`,1.5);let si=1e4;function ci(){let e=r.root,t=e.clientWidth,n=e.clientHeight;if(!(t>0&&n>0))return;let a=Math.round(t*i),o=Math.round(n*i),s=Math.min(1,4096/Math.max(a,o));ri=Math.round(a*s),ii=Math.round(o*s),ai(),mt(t/n),xr()}function li(e,t,n){return t-e>20&&t-n>20}function ui(e){let t=e.trim().toLowerCase().replace(/\.\d{3}$/,``);return t===`hatch`?1:t===`dot`||t===`dots`?2:t===`plus`||t===`cross`?3:0}function di(e){return e.trim().toLowerCase().replace(/\.\d{3}$/,``)===`target`}let fi=performance.now(),pi=0,mi=0,hi=fi;Math.max(1,window.devicePixelRatio||1);let gi=1/0,_i=-1/0,vi=1/0,yi=-1/0,bi=1e3/60,xi=.1,Si=0,Ci=0,wi=0;function Ti(e){Si++,!(Si<=4)&&(e>bi*1.15?(Ci++,wi=0):e<=bi*1.05?(wi++,Ci=0):(Ci=0,wi=0),Ci>=2&&$>ni?($=Math.max(ni,$-xi),ai(),Ci=0):wi>=8&&$<1&&($=Math.min(1,$+xi),ai(),wi=0))}function Ei(e){e??=performance.now();let t=e-fi;if(fi=e,pi++,mi+=t,e-hi>=250){let t=mi/pi,n=1e3/t;gi=Math.min(gi,n),_i=Math.max(_i,n),vi=Math.min(vi,t),yi=Math.max(yi,t),Ti(t),hi=e,pi=0,mi=0}}let Di=!1,Oi=!0;function ki(e){Di=e}function Ai(){Di||(ki(!0),fi=performance.now(),requestAnimationFrame(ji))}function ji(e){if(!Oi||a.signal.aborted){ki(!1);return}ki(!0),ti(),Ei(e),requestAnimationFrame(ji)}window.addEventListener(`resize`,ci,{signal:a.signal}),ci(),ji();{let e=new IntersectionObserver(([e])=>{Oi=e.isIntersecting,Oi&&Ai()},{rootMargin:`200px 0px`});e.observe(s);let t=new ResizeObserver(ci);t.observe(r.root);let n=new IntersectionObserver(([e])=>{if(!e.isIntersecting)return;let t=e.boundingClientRect.height-e.intersectionRect.height,r=!!e.rootBounds&&e.intersectionRect.height>=e.rootBounds.height-1;t>200&&!r||(n.disconnect(),mr=!0,gr())},{threshold:Array.from({length:101},(e,t)=>t/100)});n.observe(s),a.signal.addEventListener(`abort`,()=>{e.disconnect(),t.disconnect(),n.disconnect()})}vr(),r.handle={setCount(e){r.count=e,ur(e)},setModel(e){$n=e,_r(e)}}}var i={vertical:[3,9],sideways:[1,4]},a={ep5:`EP5`,ep12:`EP12`};function o(e,t){let{variant:n,count:o,model:s=`ep5`,reducedMotion:c=!1,modelBaseUrl:l,onReady:u,onError:d}=t,f=i[n];if(!f)throw TypeError(`createBatteryScene: unknown variant "${n}".`);let p=e=>{if(!Number.isInteger(e)||e<f[0]||e>f[1])throw RangeError(`createBatteryScene: ${n} count must be an integer from ${f[0]} to ${f[1]}, got ${e}.`)},m=e=>{if(!(e in a))throw TypeError(`createBatteryScene: unknown model "${e}".`)},h=e.querySelector(`canvas[data-battery-canvas]`);if(!h)throw TypeError(`createBatteryScene: root has no canvas[data-battery-canvas].`);if(typeof l!=`string`)throw TypeError(`createBatteryScene: modelBaseUrl is required.`);p(o),m(s);let{display:g,width:_,height:v,cursor:y}=h.style;Object.assign(h.style,{display:`block`,width:`100%`,height:`100%`});let b=new AbortController,x=!1,S=()=>{x||(x=!0,b.abort(),Object.assign(h.style,{display:g,width:_,height:v,cursor:y}))},C={root:e,canvas:h,teardown:b,sideways:n===`sideways`,count:o,model:a[s],reducedMotion:!!c,modelBaseUrl:l.endsWith(`/`)?l:`${l}/`,onReady:()=>u?.(),onError:e=>d?.(e)};try{r(C)}catch(e){return S(),queueMicrotask(()=>d?.(e)),{setCount(){},setModel(){},destroy(){}}}return{setCount(e){p(e),x||C.handle.setCount(e)},setModel(e){m(e),x||C.handle.setModel(a[e])},destroy:S}}export{o as createBatteryScene};